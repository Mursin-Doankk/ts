<?php /* Smarty version Smarty3rc4, created on 2020-11-06 16:50:10
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/complainlist.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2434435725fa57ec26168f0-70283209%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3a08824b42de07bebc7cad4d132f41a94ce28e90' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/complainlist.tpl',
      1 => 1513638412,
    ),
  ),
  'nocache_hash' => '2434435725fa57ec26168f0-70283209',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_client_complain_list'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_client_complain_list'])){?>
<section class="content container-fluid">
	<div class="row">
		<div class="col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4">
			<div class="box box-danger">
				<div class="box-header"><h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
</h3></div>
				<div class="box-body">
					<p class="lead"><?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>
</p>
				</div>
			</div>
		</div>
	</div>
</section>
<?php }else{ ?>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['complainlist'];?>
</h3>
			</div>
			<table class="table" cellpadding="1" cellspacing="0">
				<tr>
					<th style="width: 20%"><?php echo $_smarty_tpl->getVariable('lang')->value['targetnick'];?>
</th>
					<th style="width: 20%"><?php echo $_smarty_tpl->getVariable('lang')->value['sourcenick'];?>
</th>
					<th><?php echo $_smarty_tpl->getVariable('lang')->value['reason'];?>
</th>
					<th style="width: 15%"></th>
				</tr>
					<?php $_smarty_tpl->tpl_vars['i'] = new Smarty_variable("1", null, null);?>
					<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('newcomplainlist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
						<?php  $_smarty_tpl->tpl_vars['value2'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key2'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['value']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value2']->key => $_smarty_tpl->tpl_vars['value2']->value){
 $_smarty_tpl->tpl_vars['key2']->value = $_smarty_tpl->tpl_vars['value2']->key;
?>
							<tr>
								<td>
									<a href="javascript:colapse_rows('<?php echo $_smarty_tpl->getVariable('i')->value;?>
')"><i class="mdi mdi-plus-box mdi-lg" title="aus/ein-klappen" id="Pic<?php echo $_smarty_tpl->getVariable('i')->value;?>
"></i></a>
									<?php echo $_smarty_tpl->tpl_vars['key2']->value;?>

								</td>
								<td> &nbsp;</td>
								<td> <?php echo sprintf($_smarty_tpl->getVariable('lang')->value['countcomplain'],count($_smarty_tpl->tpl_vars['value2']->value));?>
</td>
								<td> 
								<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_client_complain_delete'])||$_smarty_tpl->getVariable('permoverview')->value['b_client_complain_delete']==1){?>
									<form method="post" action="index.php?site=complainlist&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
										<input type="hidden" name="tcldbid" value="<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
" />
										<input class="btn btn-flat btn-block btn-danger" type="submit" name="delall" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delall'];?>
" />
									</form>
								<?php }?>
								</td>
							</tr>
							<tr>
								<td colspan="4" class="no-padding">
									<table class="table" id="Lay<?php echo $_smarty_tpl->getVariable('i')->value;?>
" style="display:none;">
									<?php  $_smarty_tpl->tpl_vars['value3'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key3'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['value2']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value3']->key => $_smarty_tpl->tpl_vars['value3']->value){
 $_smarty_tpl->tpl_vars['key3']->value = $_smarty_tpl->tpl_vars['value3']->key;
?>
										<tr>
											<td style="width: 20%;">&nbsp;<?php echo date("d.m.Y - H:i",$_smarty_tpl->tpl_vars['value3']->value['timestamp']);?>
</td>
											<td style="width: 20%;"><?php echo secure($_smarty_tpl->tpl_vars['value3']->value['fname']);?>
</td>
											<td ><?php echo secure($_smarty_tpl->tpl_vars['value3']->value['message']);?>
</td>
											<td style="width: 15%;">
											<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_client_complain_delete'])||$_smarty_tpl->getVariable('permoverview')->value['b_client_complain_delete']==1){?>
												<form method="post" action="index.php?site=complainlist&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
													<input type="hidden" name="tcldbid" value="<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
" />
													<input type="hidden" name="fcldbid" value="<?php echo $_smarty_tpl->tpl_vars['key3']->value;?>
" />
													<input class="btn btn-flat btn-block btn-danger" type="submit" name="delete" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
" />
												</form>
											<?php }?>
											</td>
										</tr>
									<?php }} ?>
									</table>
								</td>
							</tr>
						<?php }} ?>
						<?php $_smarty_tpl->tpl_vars['i'] = new Smarty_variable(($_smarty_tpl->getVariable('i')->value+1), null, null);?>
					<?php }} ?>
			</table>
		</div>
	<?php }?>
	</div>
</section>
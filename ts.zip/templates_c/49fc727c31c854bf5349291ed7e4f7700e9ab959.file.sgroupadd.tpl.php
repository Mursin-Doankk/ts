<?php /* Smarty version Smarty3rc4, created on 2020-11-06 16:51:53
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/sgroupadd.tpl" */ ?>
<?php /*%%SmartyHeaderCode:872685685fa57f29255b10-04693864%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '49fc727c31c854bf5349291ed7e4f7700e9ab959' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/sgroupadd.tpl',
      1 => 1513638412,
    ),
  ),
  'nocache_hash' => '872685685fa57f29255b10-04693864',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_servergroup_create'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_servergroup_create'])){?>
<section class="content container-fluid">
	<div class="row">
		<div class="col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4">
			<div class="box box-danger">
				<div class="box-header"><h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
</h3></div>
				<div class="box-body">
					<p class="lead"><?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>
</p>
				</div>
			</div>
		</div>
	</div>
</section>
<?php }else{ ?>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
		<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
		<?php }?>
		<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
		<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
		<?php }?>
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['addservergroup'];?>
</h3>
			</div>
			<div class="box-body">
				<form method="post" action="index.php?site=sgroupadd&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
					<table class="table table-striped no-margin">
						<tr>
							<th width="35%"><label><?php echo $_smarty_tpl->getVariable('lang')->value['type'];?>
:</label></th>
							<td>
								<div class="radio">
									<label>
										<input type="radio" name="type" value="0" />
										<?php echo $_smarty_tpl->getVariable('lang')->value['template'];?>

									</label>
								</div>
								<div class="radio">
									<label>
										<input checked type="radio" name="type" value="1" />
										<?php echo $_smarty_tpl->getVariable('lang')->value['normal'];?>

									</label>
								</div>
								<div class="radio">
									<label>	
										<input type="radio" name="type" value="2" />
										<?php echo $_smarty_tpl->getVariable('lang')->value['query'];?>

									</label>
								</div>
							</td>
						</tr>
						<tr>
							<th><label for="new_name"><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
:</label></th>
							<td class="no-padding">
								<input type="text" class="form-control" id="new_name" name="name" />
							</td>
						</tr>
						<tr>
							<th><label for="new_copyfrom"><?php echo $_smarty_tpl->getVariable('lang')->value['copypermsfrom'];?>
:</label></th>
							<td class="no-padding">
								<select name="copyfrom" class="form-control" id="new_copyfrom">
									<option value="0">-</option>
								<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('servergroups')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
									<option value="<?php echo $_smarty_tpl->tpl_vars['value']->value['sgid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</option>
								<?php }} ?>
								</select>
							</td>
						</tr>
						<tr>
							<th><label for="new_overwrite"><?php echo $_smarty_tpl->getVariable('lang')->value['overwritegroup'];?>
:</label></th>
							<td class="no-padding">
								<select name="overwrite" class="form-control" id="new_overwrite">
									<option value="0">-</option>
								<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('servergroups')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
									<option value="<?php echo $_smarty_tpl->tpl_vars['value']->value['sgid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</option>
								<?php }} ?>
								</select>
							</td>
						</tr>
					</table>
					<input class="btn btn-flat btn-primary btn-block" type="submit" name="addgroup" value="<?php echo $_smarty_tpl->getVariable('lang')->value['add'];?>
" />
				</form>
			</div>
		</div>
	</div>
</section>
<?php }?>
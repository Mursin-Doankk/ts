<?php /* Smarty version Smarty3rc4, created on 2020-11-06 16:50:00
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/counter.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16684128175fa57eb87aece8-66413791%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '68a88b182d37a0b74f8a5eb4b5f682c3060a5a6a' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/counter.tpl',
      1 => 1513638412,
    ),
  ),
  'nocache_hash' => '16684128175fa57eb87aece8-66413791',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_client_list'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_client_list'])||isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_client_dblist'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_client_dblist'])){?>
<section class="content container-fluid">
	<div class="row">
		<div class="col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4">
			<div class="box box-danger">
				<div class="box-header"><h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
</h3></div>
				<div class="box-body">
					<p class="lead"><?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>
</p>
				</div>
			</div>
		</div>
	</div>
</section>
<?php }else{ ?>
<section class="content container-fluid">
	<div class="col-lg-6 col-lg-offset-3">
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['clientcounter'];?>
</h3>
			</div>
			<div class="box-body">
				<table class="table table-striped" cellpadding="1" cellspacing="0">
					<tr>
						<th style="width:50%"><?php echo $_smarty_tpl->getVariable('lang')->value['total'];?>
</th>
						<td style="width:50%"><?php echo $_smarty_tpl->getVariable('totalclients')->value;?>
 <?php echo $_smarty_tpl->getVariable('lang')->value['clients'];?>
</td>
					</tr>
					<tr>
						<th><?php echo $_smarty_tpl->getVariable('lang')->value['online'];?>
</th>
						<td>
							<div class="progress progress-xs">
								<div class="progress-bar progress-bar-aqua" style="width: <?php echo $_smarty_tpl->getVariable('perc_online')->value;?>
%" role="progressbar" aria-valuenow="<?php echo $_smarty_tpl->getVariable('perc_online')->value;?>
" aria-valuemin="0" aria-valuemax="100">
									<span class="sr-only"><?php echo $_smarty_tpl->getVariable('perc_online')->value;?>
%</span>
								</div>
							</div>
							<?php echo $_smarty_tpl->getVariable('count_online')->value;?>
 <?php echo $_smarty_tpl->getVariable('lang')->value['clients'];?>
 | <?php echo $_smarty_tpl->getVariable('perc_online')->value;?>
%
						</td>
					</tr>
					<tr>
						<th><?php echo $_smarty_tpl->getVariable('lang')->value['today'];?>
</th>
						<td>
							<div class="progress progress-xs">
								<div class="progress-bar progress-bar-aqua" style="width: <?php echo $_smarty_tpl->getVariable('perc_today')->value;?>
%" role="progressbar" aria-valuenow="<?php echo $_smarty_tpl->getVariable('perc_today')->value;?>
" aria-valuemin="0" aria-valuemax="100">
									<span class="sr-only"><?php echo $_smarty_tpl->getVariable('perc_today')->value;?>
%</span>
								</div>
							</div>
							<?php echo $_smarty_tpl->getVariable('count_today')->value;?>
 <?php echo $_smarty_tpl->getVariable('lang')->value['clients'];?>
 | <?php echo $_smarty_tpl->getVariable('perc_today')->value;?>
%
						</td>
					</tr>
					<tr>
						<th><?php echo $_smarty_tpl->getVariable('lang')->value['thisweek'];?>
</th>
						<td>
							<div class="progress progress-xs">
								<div class="progress-bar progress-bar-aqua" style="width: <?php echo $_smarty_tpl->getVariable('perc_week')->value;?>
%" role="progressbar" aria-valuenow="<?php echo $_smarty_tpl->getVariable('perc_week')->value;?>
" aria-valuemin="0" aria-valuemax="100">
									<span class="sr-only"><?php echo $_smarty_tpl->getVariable('perc_week')->value;?>
%</span>
								</div>
							</div>
							<?php echo $_smarty_tpl->getVariable('count_week')->value;?>
 <?php echo $_smarty_tpl->getVariable('lang')->value['clients'];?>
 | <?php echo $_smarty_tpl->getVariable('perc_week')->value;?>
%
						</td>
					</tr>
					<tr>
						<th><?php echo $_smarty_tpl->getVariable('lang')->value['thismonth'];?>
</th>
						<td>
							<div class="progress progress-xs">
								<div class="progress-bar progress-bar-aqua" style="width: <?php echo $_smarty_tpl->getVariable('perc_month')->value;?>
%" role="progressbar" aria-valuenow="<?php echo $_smarty_tpl->getVariable('perc_month')->value;?>
" aria-valuemin="0" aria-valuemax="100">
									<span class="sr-only"><?php echo $_smarty_tpl->getVariable('perc_month')->value;?>
%</span>
								</div>
							</div>
							<?php echo $_smarty_tpl->getVariable('count_month')->value;?>
 <?php echo $_smarty_tpl->getVariable('lang')->value['clients'];?>
 | <?php echo $_smarty_tpl->getVariable('perc_month')->value;?>
%
						</td>
					</tr>
				</table>
			</div>
		</div>
	<?php }?>
	</div>
</section>
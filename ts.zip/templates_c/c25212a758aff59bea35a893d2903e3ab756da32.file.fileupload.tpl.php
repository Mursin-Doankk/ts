<?php /* Smarty version Smarty3rc4, created on 2018-02-05 01:51:16
         compiled from "C:\localhost\www\Ts3WebPanel\gelistir2\templates/mrstipfan/fileupload.tpl" */ ?>
<?php /*%%SmartyHeaderCode:257495a77b894a3d092-38407209%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c25212a758aff59bea35a893d2903e3ab756da32' => 
    array (
      0 => 'C:\\localhost\\www\\Ts3WebPanel\\gelistir2\\templates/mrstipfan/fileupload.tpl',
      1 => 1513634812,
    ),
  ),
  'nocache_hash' => '257495a77b894a3d092-38407209',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
	<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
	<?php }?>
	<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
		<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
	<?php }?>
	<?php if ($_smarty_tpl->getVariable('newserverversion')->value!==true&&!empty($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_version'])){?>
		<div class="alert alert-warning"><?php echo $_smarty_tpl->getVariable('lang')->value['serverupdateav'];?>
<?php echo $_smarty_tpl->getVariable('newserverversion')->value;?>
</div>
	<?php }?>
	</div>
	<div class="row">
		<div class="col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4">
			<form enctype="multipart/form-data" action="index.php?site=fileupload&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
" method="post">
				<div class="box box-primary">
					<div class="box-header">
						<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['iconupload'];?>
</h3>
					</div>
					<div class="box-body">	
						<p><?php echo $_smarty_tpl->getVariable('lang')->value['iconupinfo'];?>
</p>
						<div class="form-group">
							<input type="hidden" name="max_file_size" value="81920" />
							<input name="thefile" type="file" class="" />						
						</div>
						<div class="form-group no-margin">
							<input type="submit" class="btn btn-flat btn-block btn-primary" name="upload" value="<?php echo $_smarty_tpl->getVariable('lang')->value['iconupload'];?>
" />
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1">
			<div class="box box-info">
				<div class="box-body">
					<form method="post" action="index.php?site=fileupload&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
						<div class="table-responsive">
							<table class="table table-striped table-vert-mid">
								<tr>
									<th width="5%"></th>
									<th><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
</th>
									<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['id'];?>
</th>
									<th class="text-center">Ma&szlig;e</th>
									<th class="text-center">Type</th>
									<th width="25%" class="text-center">
										<div class="checkbox-inline">
											<label>
												<input type="checkbox" name="checkall" value="0" onclick="check(2)" />
												<b><?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
 <?php echo $_smarty_tpl->getVariable('lang')->value['selectall'];?>
</b>
											</label>
										</div>
									</th>
								</tr>
								<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('allicons')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
								<tr>
									<td class="no-padding text-center"><img width="16" height="16" src="site/showfile.php?name=icon_<?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
&amp;port=<?php echo $_smarty_tpl->getVariable('port')->value;?>
" alt="<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
" /></td>
									<td><?php echo $_smarty_tpl->tpl_vars['key']->value;?>
</td>
									<td class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['id'];?>
</td>
									<td class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['info'][0];?>
*<?php echo $_smarty_tpl->tpl_vars['value']->value['info'][1];?>
</td>
									<td class="text-center">
									<?php if ($_smarty_tpl->tpl_vars['value']->value['info'][2]==1){?>
										.gif
									<?php }elseif($_smarty_tpl->tpl_vars['value']->value['info'][2]==2){?>
										.jpg
									<?php }elseif($_smarty_tpl->tpl_vars['value']->value['info'][2]==3){?>
										.png
									<?php }?>
									</td>
									<td class="text-center">
										<input type="checkbox" id="list<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
" name="delicons[]" value="/<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
" />
									</td>
								</tr>
								<?php }} ?>
								<tr>
									<td colspan="5"></td>
									<td>
										<input type="submit" name="delaction" class="btn btn-danger btn-flat btn-block" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
" />
									</td>
								</tr>
							</table>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</section>
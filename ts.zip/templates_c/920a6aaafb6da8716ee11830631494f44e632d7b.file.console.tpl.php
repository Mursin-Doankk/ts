<?php /* Smarty version Smarty3rc4, created on 2020-11-06 14:42:26
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/console.tpl" */ ?>
<?php /*%%SmartyHeaderCode:639496285fa560d20302f2-51654451%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '920a6aaafb6da8716ee11830631494f44e632d7b' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/console.tpl',
      1 => 1513638412,
    ),
  ),
  'nocache_hash' => '639496285fa560d20302f2-51654451',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
		<div class="box box-primary">
			<div class="box-header">
				<label for="new_command">
					<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['queryconsole'];?>
 <small><?php echo $_smarty_tpl->getVariable('lang')->value['inputbox'];?>
</small></h3>
				</label>
			</div>
			<div class="box-body">
				<form method="post" action="index.php?site=console&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
					<textarea name="command" id="new_command" class="form-control resize-vert" rows="3"></textarea>
					<input class="btn btn-primary btn-flat btn-block" type="submit" name="execute" value="<?php echo $_smarty_tpl->getVariable('lang')->value['execute'];?>
" />
				</form>
			</div>
		</div>
		<div class="box box-default">
			<div class="box-header">
				<label for="output">
					<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['queryconsole'];?>
 - <?php echo $_smarty_tpl->getVariable('lang')->value['outputbox'];?>
</h3>
				</label>
			</div>
			<div class="box-body">
				<textarea name="output" id="output" rows="10" class="form-control resize-vert" readonly><?php echo $_smarty_tpl->getVariable('showOutput')->value;?>
</textarea>	
			</div>
		</div>
	</div>
</section>
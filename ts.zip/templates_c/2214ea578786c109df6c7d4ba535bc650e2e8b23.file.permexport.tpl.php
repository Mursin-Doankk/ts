<?php /* Smarty version Smarty3rc4, created on 2020-11-06 16:54:23
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/permexport.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14441298575fa57fbf30c163-71495899%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2214ea578786c109df6c7d4ba535bc650e2e8b23' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/permexport.tpl',
      1 => 1513638412,
    ),
  ),
  'nocache_hash' => '14441298575fa57fbf30c163-71495899',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
		<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
		<?php }?>
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['permexport'];?>
</h3>
			</div>
			<div class="box-body">
				<p><?php echo $_smarty_tpl->getVariable('lang')->value['permexdesc'];?>
</p>
				<form method="post" action="index.php?site=permexport&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
					<table class="table table-striped">
						<tr>
							<th><label for="new_sourcemode"><?php echo $_smarty_tpl->getVariable('lang')->value['sourcetype'];?>
</label></th>
							<td>
								<select class="form-control" id="new_sourcemode" name="sourcemode">
									<option value="1"><?php echo $_smarty_tpl->getVariable('lang')->value['servergroup'];?>
</option>
									<option value="2"><?php echo $_smarty_tpl->getVariable('lang')->value['channelgroup'];?>
</option>
									<option value="3"><?php echo $_smarty_tpl->getVariable('lang')->value['channel'];?>
</option>
									<option value="4"><?php echo $_smarty_tpl->getVariable('lang')->value['client'];?>
</option>
								</select> 
							</td>
						</tr>
						<tr>
							<th><label for="new_sourceid"><?php echo $_smarty_tpl->getVariable('lang')->value['sourceid'];?>
</label></th>
							<td><input type="text" class="form-control" id="new_sourceid" name="sourceid" /></td>
						</tr>
						<tr>
							<th><label for="new_targetmode"><?php echo $_smarty_tpl->getVariable('lang')->value['targettype'];?>
</label></th>
							<td>
								<select class="form-control" id="new_targetmode" name="targetmode">
									<option value="1"><?php echo $_smarty_tpl->getVariable('lang')->value['servergroup'];?>
</option>
									<option value="2"><?php echo $_smarty_tpl->getVariable('lang')->value['channelgroup'];?>
</option>
									<option value="3"><?php echo $_smarty_tpl->getVariable('lang')->value['channel'];?>
</option>
									<option value="4"><?php echo $_smarty_tpl->getVariable('lang')->value['client'];?>
</option>
								</select> 
							</td>
						</tr>
						<tr>
							<th><label for="new_targetid"><?php echo $_smarty_tpl->getVariable('lang')->value['targetid'];?>
</label></th>
							<td><input type="text" name="targetid" class="form-control" id="new_targetid" /></td>
						</tr>
					</table>
					<input class="btn btn-primary btn-flat btn-block" type="submit" name="showcommands" value="<?php echo $_smarty_tpl->getVariable('lang')->value['view'];?>
" />
					<?php if (isset($_POST['showcommands'])&&empty($_smarty_tpl->getVariable('error')->value)){?>
					<textarea name="showfield" cols="50" rows="10" readonly class="form-control resize-vert"><?php echo $_smarty_tpl->getVariable('permexport')->value;?>
</textarea>
					<?php }?>
				</form>
			</div>
		</div>
	</div>
</section>
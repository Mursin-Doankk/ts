<?php /* Smarty version Smarty3rc4, created on 2020-10-31 23:09:10
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/showupdate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15721538335f9dee960411a5-46246296%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'db7b7ecba50db86976d5cc40ed8464e31c21581e' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/showupdate.tpl',
      1 => 1513638412,
    ),
  ),
  'nocache_hash' => '15721538335f9dee960411a5-46246296',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('newwiversion')->value)){?>
<div class="alert alert-warning">
	<?php echo $_smarty_tpl->getVariable('newwiversion')->value;?>

</div>
<?php }?>
<?php /* Smarty version Smarty3rc4, created on 2018-02-05 01:48:08
         compiled from "..\templates/mrstipfan\interactive.tpl" */ ?>
<?php /*%%SmartyHeaderCode:52475a77b7d8934477-15578072%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '33af2d9aa4b02346e0d39b26c4d0a3fbbda41038' => 
    array (
      0 => '..\\templates/mrstipfan\\interactive.tpl',
      1 => 1517328280,
    ),
  ),
  'nocache_hash' => '52475a77b7d8934477-15578072',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="de">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/ionicons/1.5.2/css/ionicons.min.css">
	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/admin-lte/2.3.11/css/AdminLTE.min.css">
	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/admin-lte/2.3.11/css/skins/_all-skins.min.css">
	<link href="../templates/<?php echo $_smarty_tpl->getVariable('tmpl')->value;?>
/assets/css/materialdesignicons.css" rel="stylesheet" />
	<link href="../templates/<?php echo $_smarty_tpl->getVariable('tmpl')->value;?>
/assets/css/mdi-customs.css" rel="stylesheet" />
	<link href="../templates/<?php echo $_smarty_tpl->getVariable('tmpl')->value;?>
/assets/css/customs.css" rel="stylesheet" />
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jQuery-slimScroll/1.3.8/jquery.slimscroll.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/fastclick/1.0.6/fastclick.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/admin-lte/2.3.11/js/app.min.js"></script>
	<title>TeamSpeak 3 - Yönetim Paneli</title>
	<script type="text/javascript">
	<?php if (!isset($_GET['clid'])){?>
		var pageTitle = "<?php echo $_smarty_tpl->getVariable('lang')->value['server'];?>
 <?php echo $_smarty_tpl->getVariable('lang')->value['massaction'];?>
";
	<?php }?>
	</script>
</head>
<body style="background: #ecf0f5;" onload="window.parent.postMessage(pageTitle, '*')" class="no-padding no-margin">
<?php if (!isset($_GET['clid'])){?>
	<form class="form-inline" method="post" name="f2" action="interactive.php?sid=<?php echo $_GET['sid'];?>
">
		<div class="row">
			<label class="col-md-3"><?php echo $_smarty_tpl->getVariable('lang')->value['select'];?>
:</label>
			<div class="col-md-9">
				<select class="form-control" name="action" onchange="this.form.submit()">
					<option disabled <?php if ($_POST['action']==''){?> selected <?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['select'];?>
</option>
					<option value="kick" <?php if ($_POST['action']=='kick'){?> selected <?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['kick'];?>
</option>
					<option value="ban" <?php if ($_POST['action']=='ban'){?> selected <?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['ban'];?>
</option>
					<option value="move" <?php if ($_POST['action']=='move'){?> selected <?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['move'];?>
</option>
				</select>
			</div>
		</div>
	</form>
	<br />
	<?php if ($_POST['action']=='move'){?>
	<form method="post" name="f1" target="opener" action="../index.php?site=serverview&amp;sid=<?php echo $_GET['sid'];?>
">
		<h4><?php echo $_smarty_tpl->getVariable('lang')->value['massmover'];?>
</h4>
		<div class="row form-group">
			<div class="col-md-12">
				<div class="checkbox">
					<label>
						<b>
							<input type="checkbox" name="moveall" value="1" /> <?php echo $_smarty_tpl->getVariable('lang')->value['moveallclients'];?>

						</b>
					</label>
				</div>
			</div>
		</div>
		<div class="row form-group">
			<label class="col-md-3">
				<?php echo $_smarty_tpl->getVariable('lang')->value['moveclientsbysgroup'];?>

			</label>
			<div class="col-md-9">
				<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('servergrouplist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
				<?php if ($_smarty_tpl->tpl_vars['value']->value['type']!=0){?>
				<div class="checkbox">
					<label> 
						<input type="checkbox" name="movebysgroup[]" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['sgid'];?>
" />
						<?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>

					</label>
				</div>
				<?php }?>
				<?php }} ?>
			</div>
		</div>
		<div class="row form-group">
			<label class="col-md-3">
				<?php echo $_smarty_tpl->getVariable('lang')->value['moveclientsbycgroup'];?>

			</label>
			<div class="col-md-9">
				<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channelgrouplist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
				<?php if ($_smarty_tpl->tpl_vars['value']->value['type']!=0){?>
				<div class="checkbox">
					<label> 
						<input type="checkbox" name="movebycgroup[]" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
" />
						<?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>

					</label>
				</div>
				<?php }?>
				<?php }} ?>
			</div>
		</div>
		<div class="row form-group">
			<label class="col-md-3" for="new_movebycid"><?php echo $_smarty_tpl->getVariable('lang')->value['movefrom'];?>
:</label>
			<div class="col-md-9">
				<select class="form-control" id="new_movebycid" name="movebycid[]" size="3" multiple="multiple">
				<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channellist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<option value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['channel_name'];?>
</option>
				<?php }} ?>
				</select>
			</div>
		</div>
		<div class="row form-group">
			<label class="col-md-3" for="new_cid"><?php echo $_smarty_tpl->getVariable('lang')->value['moveto'];?>
:</label>
			<div class="col-md-9">
				<select class="form-control" id="new_cid" name="cid" size="3">
				<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channellist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<option value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['channel_name'];?>
</option>
				<?php }} ?>
				</select>
			</div>
		</div>
		<div class="row form-group">
			<div class="col-md-12">
				<input class="btn btn-primary btn-flat btn-block" type="submit" name="sendmassban" value="<?php echo $_smarty_tpl->getVariable('lang')->value['move'];?>
" onclick="parent.closeIFrame();" />
			</div>
		</div>
	</form>
	<?php }?>
	<?php if ($_POST['action']=='kick'){?>
	<form method="post" name="f1" target="opener" action="../index.php?site=serverview&amp;sid=<?php echo $_GET['sid'];?>
">
		<h4><?php echo $_smarty_tpl->getVariable('lang')->value['masskicker'];?>
</h4>
		<div class="row form-group">
			<div class="col-md-12">
				<div class="checkbox">
					<label>
						<b>
							<input type="checkbox" name="kickall" value="1" /> <?php echo $_smarty_tpl->getVariable('lang')->value['kickallclients'];?>

						</b>
					</label>
				</div>
			</div>
		</div>
		<div class="row form-group">
			<label class="col-md-3">
				<?php echo $_smarty_tpl->getVariable('lang')->value['kickclientsbysgroup'];?>

			</label>
			<div class="col-md-9">
				<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('servergrouplist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
				<?php if ($_smarty_tpl->tpl_vars['value']->value['type']!=0){?>
				<div class="checkbox">
					<label> 
						<input type="checkbox" name="kickbysgroup[]" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['sgid'];?>
" />
						<?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>

					</label>
				</div>
				<?php }?>
				<?php }} ?>
			</div>
		</div>
		<div class="row form-group">
			<label class="col-md-3">
				<?php echo $_smarty_tpl->getVariable('lang')->value['kickclientsbycgroup'];?>

			</label>
			<div class="col-md-9">
				<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channelgrouplist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
				<?php if ($_smarty_tpl->tpl_vars['value']->value['type']!=0){?>
				<div class="checkbox">
					<label> 
						<input type="checkbox" name="kickbycgroup[]" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
" />
						<?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>

					</label>
				</div>
				<?php }?>
				<?php }} ?>
			</div>
		</div>
		<div class="row form-group">
			<label class="col-md-3" for="new_kickbycid"><?php echo $_smarty_tpl->getVariable('lang')->value['kickfrom'];?>
:</label>
			<div class="col-md-9">
				<select class="form-control" id="new_kickbycid" name="kickbycid[]" size="3" multiple="multiple">
				<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channellist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<option value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['channel_name'];?>
</option>
				<?php }} ?>
				</select>
			</div>
		</div>
		<div class="row form-group">
			<label class="col-md-3" for="new_kickmsg"><?php echo $_smarty_tpl->getVariable('lang')->value['kickmsg'];?>
:</label>
			<div class="col-md-9">
				<input type="text" name="kickmsg" id="new_kickmsg" class="form-control">
			</div>
		</div>
		<div class="row form-group">
			<div class="col-md-12">
				<input class="btn btn-primary btn-flat btn-block" type="submit" name="sendmasskick" value="<?php echo $_smarty_tpl->getVariable('lang')->value['kick'];?>
" onclick="self.close()" />
			</div>
		</div>
	</form>
	<?php }?>
	<?php if ($_POST['action']=='ban'){?>
	<form class="form-inline" method="post" name="f1" target="opener" action="../index.php?site=serverview&amp;sid=<?php echo $_GET['sid'];?>
">
		<h4><?php echo $_smarty_tpl->getVariable('lang')->value['massban'];?>
</h4>
		<div class="row form-group">
			<div class="col-md-12">
				<div class="checkbox">
					<label>
						<b>
							<input type="checkbox" name="banall" value="1" /> <?php echo $_smarty_tpl->getVariable('lang')->value['banallclients'];?>

						</b>
					</label>
				</div>
			</div>
		</div>
		<div class="row form-group">
			<label class="col-md-3">
				<?php echo $_smarty_tpl->getVariable('lang')->value['banclientsbysgroup'];?>

			</label>
			<div class="col-md-9">
				<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('servergrouplist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
				<?php if ($_smarty_tpl->tpl_vars['value']->value['type']!=0){?>
				<div class="checkbox">
					<label> 
						<input type="checkbox" name="banbysgroup[]" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['sgid'];?>
" />
						<?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>

					</label>
				</div>
				<?php }?>
				<?php }} ?>
			</div>
		</div>
		<div class="row form-group">
			<label class="col-md-3">
				<?php echo $_smarty_tpl->getVariable('lang')->value['banclientsbycgroup'];?>

			</label>
			<div class="col-md-9">
				<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channelgrouplist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
				<?php if ($_smarty_tpl->tpl_vars['value']->value['type']!=0){?>
				<div class="checkbox">
					<label> 
						<input type="checkbox" name="banbysgroup[]" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
" />
						<?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>

					</label>
				</div>
				<?php }?>
				<?php }} ?>
			</div>
		</div>
		<div class="row form-group">
			<label class="col-md-3" for="new_banbycid"><?php echo $_smarty_tpl->getVariable('lang')->value['banfrom'];?>
:</label>
			<div class="col-md-9">
				<select class="form-control" id="new_banbycid" name="banbycid[]" size="3" multiple="multiple">
				<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channellist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<option value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['channel_name'];?>
</option>
				<?php }} ?>
				</select>
			</div>
		</div>
		<div class="row form-group">
			<label class="col-md-3" for="new_banmsg"><?php echo $_smarty_tpl->getVariable('lang')->value['banmsg'];?>
:</label>
			<div class="col-md-9">
				<input type="text" name="banmsg" id="new_banmsg" class="form-control">
			</div>
		</div>
		<div class="row form-group">
			<label class="col-md-3" for="new_bantime"><?php echo $_smarty_tpl->getVariable('lang')->value['bantime'];?>
:</label>
			<div class="col-md-9">
				<div class="input-group">
					<input type="number" name="bantime" id="new_bantime" class="form-control" min="-1" step="1">
					<div class="input-group-addon">
						<?php echo $_smarty_tpl->getVariable('lang')->value['seconds'];?>

					</div>
				</div>
			</div>
		</div>
		<div class="row form-group">
			<div class="col-md-12">
				<input class="btn btn-primary btn-flat btn-block" type="submit" name="sendmassban" value="<?php echo $_smarty_tpl->getVariable('lang')->value['ban'];?>
" onclick="parent.closeIFrame();" />
			</div>
		</div>
	</form>
	<?php }?>
<?php }else{ ?>
	<form method="post" name="f2" action="interactive.php?sid=<?php echo $_GET['sid'];?>
&amp;clid=<?php echo $_GET['clid'];?>
&amp;nick=<?php echo $_GET['nick'];?>
">
		<table class="table">
			<tr>
				<td class="maincat" colspan="2"><?php echo $_GET['nick'];?>
</td>
			</tr>
			<tr>
				<td class="green1"><?php echo $_smarty_tpl->getVariable('lang')->value['select'];?>
:</td>
				<td class="green1">
					<select name="action" onchange="this.form.submit()">
						<option><?php echo $_smarty_tpl->getVariable('lang')->value['select'];?>
</option>
						<option value="kick"><?php echo $_smarty_tpl->getVariable('lang')->value['kick'];?>
</option>
						<option value="ban"><?php echo $_smarty_tpl->getVariable('lang')->value['ban'];?>
</option>
						<option value="poke"><?php echo $_smarty_tpl->getVariable('lang')->value['poke'];?>
</option>
						<option value="move"><?php echo $_smarty_tpl->getVariable('lang')->value['move'];?>
</option>
					</select>
				</td>
			</tr>
		</table>
		</form>
		<br />
	<?php if ($_POST['action']=='kick'){?>
	<form method="post" name="f1" target="opener" action="../index.php?site=serverview&amp;sid=<?php echo $_GET['sid'];?>
" onsubmit="window.close()">
		<table class="border" cellpadding="1" cellspacing="0">
			<tr>
				<td class="maincat" colspan="2"><?php echo $_smarty_tpl->getVariable('lang')->value['kick'];?>
 <?php echo $_GET['nick'];?>
</td>
			</tr>
			<tr>
				<td class="green1"><?php echo $_smarty_tpl->getVariable('lang')->value['kickmsg'];?>
:</td>
				<td class="green1"><input type="text" name="kickmsg" /></td>
			</tr>
			<tr>
				<td class="green2"><?php echo $_smarty_tpl->getVariable('lang')->value['option'];?>
:</td>
				<td class="green2">
				<input type="hidden" name="clid" value="<?php echo $_GET['clid'];?>
" />
				<input class="button" type="submit" name="sendkick" value="<?php echo $_smarty_tpl->getVariable('lang')->value['kick'];?>
" onclick="self.close()">
				</td>
			</tr>
		</table>
	</form>
	<?php }?>

	<?php if ($_POST['action']=='ban'){?>
	<form method="post" name="f1" target="opener" action="../index.php?site=serverview&amp;sid=<?php echo $_GET['sid'];?>
">
		<table class="border" cellpadding="1" cellspacing="0">
			<tr>
				<td class="maincat" colspan="2"><?php echo $_smarty_tpl->getVariable('lang')->value['ban'];?>
 <?php echo $_GET['nick'];?>
</td>
			</tr>
			<tr>
				<td class="green1"><?php echo $_smarty_tpl->getVariable('lang')->value['banmsg'];?>
:</td>
				<td class="green1">
				<input type="text" name="banmsg"></td>
			</tr>
			<tr>
				<td class="green2"><?php echo $_smarty_tpl->getVariable('lang')->value['bantime'];?>
:</td>
				<td class="green2">
				<input type="text" name="bantime"><?php echo $_smarty_tpl->getVariable('lang')->value['seconds'];?>
</td>
			</tr>
			<tr>
				<td class="green1"><?php echo $_smarty_tpl->getVariable('lang')->value['option'];?>
:</td>
				<td class="green1">
				<input type="hidden" name="clid" value="<?php echo $_GET['clid'];?>
" />
				<input class="button" type="submit" name="sendban" value="<?php echo $_smarty_tpl->getVariable('lang')->value['ban'];?>
" onclick="self.close()">
				</td>
			</tr>
		</table>
	</form>
	<?php }?>

	<?php if ($_POST['action']=='poke'){?>
	<form method="post" name="f1" target="opener" action="../index.php?site=serverview&amp;sid=<?php echo $_GET['sid'];?>
">
		<table class="border" cellpadding="1" cellspacing="0">
			<tr>
				<td class="maincat" colspan="2"><?php echo $_smarty_tpl->getVariable('lang')->value['poke'];?>
 <?php echo $_GET['nick'];?>
</td>
			</tr>
			<tr>
				<td class="green1"><?php echo $_smarty_tpl->getVariable('lang')->value['pokemsg'];?>
:</td>
				<td class="green1">
				<input type="text" name="pokemsg"></td>
			<tr>
				<td class="green2"><?php echo $_smarty_tpl->getVariable('lang')->value['option'];?>
:</td>
				<td class="green2">
				<input type="hidden" name="clid" value="<?php echo $_GET['clid'];?>
" />
				<input class="button" type="submit" name="sendpoke" value="<?php echo $_smarty_tpl->getVariable('lang')->value['poke'];?>
" onclick="self.close()">
				</td>
			</tr>
		</table>
		</form>
	<?php }?>
	<?php if ($_POST['action']=='move'){?>
	<form method="post" name="f1" target="opener" action="../index.php?site=serverview&amp;sid=<?php echo $_GET['sid'];?>
">
		<table class="border" cellpadding="1" cellspacing="0">
			<tr>
				<td class="maincat" colspan="2"><?php echo $_smarty_tpl->getVariable('lang')->value['move'];?>
 <?php echo $_smarty_tpl->getVariable('_GET')->value['nick'];?>
</td>
			</tr>
			<tr>
				<td class="green1"><?php echo $_smarty_tpl->getVariable('lang')->value['move'];?>
:</td>
				<td class="green1">
				<select name="cid">
				<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channellist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<option value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['channel_name'];?>
</option>";
				<?php }} ?>
				</select>
				</td>
			<tr>
				<td class="green2"><?php echo $_smarty_tpl->getVariable('lang')->value['option'];?>
:</td>
				<td class="green2">
				<input type="hidden" name="clid" value="<?php echo $_GET['clid'];?>
" />
				<input class="button" type="submit" name="sendmove" value="<?php echo $_smarty_tpl->getVariable('lang')->value['move'];?>
" onclick="self.close()">
				</td>
			</tr>
		</table>
	</form>
	<?php }?>
<?php }?>
</body>
</html>
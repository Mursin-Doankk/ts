<?php /* Smarty version Smarty3rc4, created on 2018-02-05 10:06:39
         compiled from "C:\localhost\www\Ts3WebPanel\gelistir2\templates/mrstipfan/banlist.tpl" */ ?>
<?php /*%%SmartyHeaderCode:301385a782cafe16040-87765496%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aeeb9f19a33d4dd2e43fdc8ee916d4275be85b5e' => 
    array (
      0 => 'C:\\localhost\\www\\Ts3WebPanel\\gelistir2\\templates/mrstipfan/banlist.tpl',
      1 => 1513634812,
    ),
  ),
  'nocache_hash' => '301385a782cafe16040-87765496',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include 'C:\localhost\www\Ts3WebPanel\gelistir2\libs\Smarty\libs\plugins\modifier.date_format.php';
?><?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_client_ban_list'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_client_ban_list'])){?>
<section class="content container-fluid">
	<div class="row">
		<div class="col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4">
			<div class="box box-danger">
				<div class="box-header"><h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
</h3></div>
				<div class="box-body">
					<p class="lead"><?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>
</p>
				</div>
			</div>
		</div>
	</div>
</section>
<?php }else{ ?>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
		<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
		<?php }?>
		<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
		<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
		<?php }?>
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['banlist'];?>
</h3>
			</div>
			<div class="box-body">
				<table class="table">
					<tr>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['banid'];?>
</th>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['ip'];?>
/<?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
/<?php echo $_smarty_tpl->getVariable('lang')->value['uniqueid'];?>
</th>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['created'];?>
</th>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['invokername'];?>
</th>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['invokeruid'];?>
</th>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['reason'];?>
</th>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['length'];?>
</th>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['enforcement'];?>
</th>
						<th></th>
					</tr>
					<?php if (!empty($_smarty_tpl->getVariable('banlist')->value)){?>
						<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('banlist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
							<tr>
								<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['banid'];?>
</td>
								<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['ip'];?>
<?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
<?php echo $_smarty_tpl->tpl_vars['value']->value['uid'];?>
</td>
								<td style="vertical-align: middle;" class="text-center"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['value']->value['created'],"%d.%m.%Y - %H:%M:%S");?>
</td>
								<td style="vertical-align: middle;" class="text-center"><?php echo secure($_smarty_tpl->tpl_vars['value']->value['invokername']);?>
</td>
								<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['invokeruid'];?>
</td>
								<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['reason'];?>
</td>
								<td style="vertical-align: middle;" class="text-center"><?php if (isset($_smarty_tpl->tpl_vars['value']->value['duration'])){?> <?php echo $_smarty_tpl->tpl_vars['value']->value['duration'];?>
<?php }else{ ?>0<?php }?></td>
								<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['enforcement'];?>
</td>
								<td style="vertical-align: middle;" class="text-center no-padding">
								<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_client_ban_delete'])||$_smarty_tpl->getVariable('permoverview')->value['b_client_ban_delete']==1){?>
								<form method="post" action="index.php?site=banlist&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
									<input type="hidden" name="banid" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['banid'];?>
" />
									<input class="btn btn-danger btn-flat" type="submit" name="unban" value="Unban" />
								</form>
								<?php }?>
								</td>
							</tr>
							<?php $_smarty_tpl->tpl_vars['change_col'] = new Smarty_variable(($_smarty_tpl->getVariable('change_col')->value+1), null, null);?>
						<?php }} ?>
					<?php }?>
				</table>
			</div>
		</div>
	</div>
</section>
<?php }?>
<?php /* Smarty version Smarty3rc4, created on 2020-11-06 16:52:18
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/serverbackup.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16465897725fa57f426a3079-97042305%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '098ff381428134019fc05accb444980ee421b846' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/serverbackup.tpl',
      1 => 1517332493,
    ),
  ),
  'nocache_hash' => '16465897725fa57f426a3079-97042305',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include '/home/victoryf/public_html/ts3panel/libs/Smarty/libs/plugins/modifier.date_format.php';
?><section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
	<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
	<?php }?>
	<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
		<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
	<?php }?>
		<div class="box box-warning">
			<div class="box-body">
				<p><?php echo $_smarty_tpl->getVariable('lang')->value['servbackdesc'];?>
</p>
				<p><?php echo $_smarty_tpl->getVariable('lang')->value['snapwarning'];?>
</p>
			</div>	
		</div>
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['serverbackups'];?>
</h3>		
			</div>
			<div class="box-body">
				<table class="table table-striped">
					<tr>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['created'];?>
</th>
					<?php if (isset($_smarty_tpl->getVariable('files')->value[0])&&!empty($_smarty_tpl->getVariable('files')->value[0])||isset($_smarty_tpl->getVariable('folder')->value[2])&&!empty($_smarty_tpl->getVariable('folder')->value[2])){?>
						<?php if (isset($_POST['backupdate'])){?>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['server'];?>
</th>
						<?php }?>
						<th></th>
					<?php }else{ ?>
						<th></th>
					<?php }?>
					</tr>
					<?php if (isset($_smarty_tpl->getVariable('files')->value[0])&&!empty($_smarty_tpl->getVariable('files')->value[0])||isset($_smarty_tpl->getVariable('folder')->value[2])&&!empty($_smarty_tpl->getVariable('folder')->value[2])){?>
						<?php if (!isset($_POST['backupdate'])){?>
							<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('folder')->value[2]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<tr>
						<td style="vertical-align: middle; width: 50%;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value;?>
</td>
						<td colspan="2" style="vertical-align: middle;" class="text-center no-padding">
							<form style="display: inline;" method="post" action="index.php?site=serverbackup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
								<input type="hidden" name="backupdate" value="<?php echo $_smarty_tpl->tpl_vars['value']->value;?>
" />
								<input type="submit" class="btn btn-flat btn-sm btn-warning" name="chose" value="Seç" />
							</form>
							<form style="display: inline;" method="post" action="index.php?site=serverbackup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
								<input type="hidden" name="backupdate" value="<?php echo $_smarty_tpl->tpl_vars['value']->value;?>
" />
								<input class="btn btn-flat btn-sm btn-danger" type="submit" name="deleteall" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
" />
							</form>
						</td>
					</tr>
							<?php }} ?>
						<?php }else{ ?>
							<?php if (isset($_smarty_tpl->getVariable('files')->value[0])){?>
								<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('files')->value[0]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<tr>
						<td style="vertical-align: middle; width: 30%;" class="text-center"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['value']->value['timestamp'],"%d.%m.%Y - %H:%M:%S");?>
</td>
						<td style="vertical-align: middle; width: 30%;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
</td>
						<td style="vertical-align: middle;" class="text-center no-padding">
							<form method="post" style="display: inline;" action="index.php?site=serverbackup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
								<input type="hidden" name="backupid" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['timestamp'];?>
" />
								<input type="hidden" name="fileport" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
" />
								<input type="hidden" name="backupdate" value="<?php echo $_POST['backupdate'];?>
" />
								<input class="btn btn-flat btn-sm btn-warning" type="submit" name="deploy" value="<?php echo $_smarty_tpl->getVariable('lang')->value['deploy'];?>
" />
							</form>
							<form method="post" style="display: inline;" action="index.php?site=serverbackup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
								<input type="hidden" name="backupid" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['timestamp'];?>
" />
								<input type="hidden" name="fileport" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
" />
								<input type="hidden" name="backupdate" value="<?php echo $_POST['backupdate'];?>
" />
								<input class="btn btn-flat btn-sm btn-danger" type="submit" name="delete" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
" />
							</form>
						</td>
					</tr>
						<?php }} ?>
					<?php }else{ ?>
					<tr>
						<td colspan="3" class="text-center">Yedek bulunamadı!</td>
					</tr>
							<?php }?>
						<?php }?>
					<?php }else{ ?>
					<tr>
						<td colspan="3" class="text-center">Yedek bulunamadı!</td>
					</tr>
					<?php }?>
				</table>
			</div>
		</div>

<?php if ($_smarty_tpl->getVariable('hoststatus')->value==true){?> 
		<div class="box box-info">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['host'];?>
 <?php echo $_smarty_tpl->getVariable('lang')->value['serverbackups'];?>
</h3>
			</div>
			<div class="box-body">
				<table class="table table-striped">
					<tr>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['created'];?>
</th>
					<?php if (isset($_smarty_tpl->getVariable('files')->value[0])&&!empty($_smarty_tpl->getVariable('files')->value[0])||isset($_smarty_tpl->getVariable('folder')->value[2])&&!empty($_smarty_tpl->getVariable('folder')->value[2])){?>
						<?php if (isset($_POST['backupdate'])){?>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['server'];?>
</th>
						<?php }?>
						<th></th>
					<?php }else{ ?>
						<th></th>
					<?php }?>
					</tr>
					<?php if (isset($_smarty_tpl->getVariable('files')->value[1])&&!empty($_smarty_tpl->getVariable('files')->value[1])||isset($_smarty_tpl->getVariable('folder')->value[1])&&!empty($_smarty_tpl->getVariable('folder')->value[1])){?>
						<?php if (!isset($_POST['backupdate'])){?>
							<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('folder')->value[1]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<tr>
						<td style="vertical-align: middle; width: 50%;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value;?>
</td>
						<td colspan="2" style="vertical-align: middle;" class="text-center">
						<form method="post" style="display: inline;" action="index.php?site=serverbackup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
							<input type="hidden" name="backupdate" value="<?php echo $_smarty_tpl->tpl_vars['value']->value;?>
" />
							<input type="submit" class="btn btn-flat btn-sm btn-warning" name="chose" value="Ausw&auml;hlen" />
						</form>
						<form method="post" style="display: inline;" action="index.php?site=serverbackup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
							<input type="hidden" name="hostbackup" value="1" />
							<input type="hidden" name="backupdate" value="<?php echo $_smarty_tpl->tpl_vars['value']->value;?>
" />
							<input class="btn btn-flat btn-sm btn-danger" type="submit" name="deleteall" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
" />
						</form>
						</td>
					</tr>
							<?php }} ?>
						<?php }else{ ?>
							<?php if (isset($_smarty_tpl->getVariable('files')->value[1])){?>
								<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('files')->value[1]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<tr>
						<td style="vertical-align: middle; width: 30%" class="text-center"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['value']->value['timestamp'],"%d.%m.%Y - %H:%M:%S");?>
</td>
						<td style="vertical-align: middle; width: 30%" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
</td>
						<td style="vertical-align: middle;" class="text-center no-padding">
							<form method="post" style="display: inline;" action="index.php?site=serverbackup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
								<input type="hidden" name="hostbackup" value="1" />
								<input type="hidden" name="backupdate" value="<?php echo $_POST['backupdate'];?>
" />
								<input type="hidden" name="backupid" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['timestamp'];?>
" />
								<input type="hidden" name="fileport" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
" />
								<input class="btn btn-flat btn-sm btn-warning" type="submit" name="deploy" value="<?php echo $_smarty_tpl->getVariable('lang')->value['deploy'];?>
" />
							</form>
							<form method="post" style="display: inline;" action="index.php?site=serverbackup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
								<input type="hidden" name="hostbackup" value="1" />
								<input type="hidden" name="backupdate" value="<?php echo $_POST['backupdate'];?>
" />
								<input type="hidden" name="backupid" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['timestamp'];?>
" />
								<input type="hidden" name="fileport" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
" />
								<input class="btn btn-flat btn-sm btn-danger" type="submit" name="delete" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
" />
							</form>
						</td>
					</tr>
						<?php }} ?>
					<?php }else{ ?>
					<tr>
						<td colspan="3" class="text-center">No Backups found!</td>
					</tr>
							<?php }?>
						<?php }?>
					<?php }else{ ?>
					<tr>
						<td colspan="3" class="text-center">No Backups found!</td>
					</tr>
					<?php }?>
				</table>
			</div>
		</div>
<?php }?>
		<div class="box box-success">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['createserverbackup'];?>
</h3>
			</div>
			<div class="box-body">
				<br />
				<div class="row">
					<div class="col-md-6">
						<form method="post" action="index.php?site=serverbackup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
							<input class="btn btn-flat btn-block btn-primary" type="submit" name="create" value="<?php echo $_smarty_tpl->getVariable('lang')->value['create'];?>
" />
						</form>
					</div>
					<?php if ($_smarty_tpl->getVariable('hoststatus')->value==true){?>
					<div class="col-md-6">
						<form method="post" action="index.php?site=serverbackup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
							<input type="hidden" name="hostbackup" value="1" />
							<input class="btn btn-flat btn-block btn-info" type="submit" name="create" value="<?php echo $_smarty_tpl->getVariable('lang')->value['host'];?>
 <?php echo $_smarty_tpl->getVariable('lang')->value['create'];?>
" />
						</form>
					</div>
					<?php }?>
				</div>
			</div>
		</div>
	</div>
</section>
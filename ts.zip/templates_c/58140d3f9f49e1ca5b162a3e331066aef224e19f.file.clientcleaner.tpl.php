<?php /* Smarty version Smarty3rc4, created on 2020-11-06 16:50:15
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/clientcleaner.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2488306575fa57ec7d02308-54961898%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '58140d3f9f49e1ca5b162a3e331066aef224e19f' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/clientcleaner.tpl',
      1 => 1513638412,
    ),
  ),
  'nocache_hash' => '2488306575fa57ec7d02308-54961898',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
		<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
		<?php }?>
		<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
		<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
		<?php }?>
		<?php if (isset($_smarty_tpl->getVariable('deleted')->value)){?>
		<div class="alert alert-success"><?php echo $_smarty_tpl->getVariable('deleted')->value;?>
</div>
		<?php }?>
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['clientcleaner'];?>
</h3>
			</div>
			<div class="box-body">
				<form method="post" class="form-inline" action="index.php?site=clientcleaner&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
					<table class="table">
						<tr>
							<td><label><?php echo $_smarty_tpl->getVariable('lang')->value['deleteallclientsoffline'];?>
<input class="form-control" type="text" name="number" value="30"<td style="vertical-align: middle;" colspan="2" class="no-padding text-center">/><?php echo $_smarty_tpl->getVariable('lang')->value['deleteallclientsoffline2'];?>
</label></td>
						</tr>
						<tr>
							<td><?php echo $_smarty_tpl->getVariable('lang')->value['checkgroupsprotected'];?>
</td>
						</tr>
						<tr>
							<td>
								<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('sgrouplist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
								<div class="checkbox">
									<label>
										<input type="checkbox" name="sgroups[]" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['sgid'];?>
" />
										<?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>

									</label>
								</div>
								<br />
								<?php }} ?>
							</td>
						</tr>
						<tr>
							<td><input type="submit" class="btn btn-primary btn-flat btn-block" name="cleanit" value="<?php echo $_smarty_tpl->getVariable('lang')->value['clean'];?>
" /></td>
						</tr>
					</table>
				</form>
			</div>
		</div>
	</div>
</section>
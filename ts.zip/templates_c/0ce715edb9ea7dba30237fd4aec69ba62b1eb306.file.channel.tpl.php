<?php /* Smarty version Smarty3rc4, created on 2020-11-06 16:48:41
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/channel.tpl" */ ?>
<?php /*%%SmartyHeaderCode:18384580585fa57e69d00c49-33617921%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0ce715edb9ea7dba30237fd4aec69ba62b1eb306' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/channel.tpl',
      1 => 1513638412,
    ),
  ),
  'nocache_hash' => '18384580585fa57e69d00c49-33617921',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_channel_list'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_channel_list'])){?>
<section class="content container-fluid">
	<div class="row">
		<div class="col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4">
			<div class="box box-danger">
				<div class="box-header"><h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
</h3></div>
				<div class="box-body">
					<p class="lead"><?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>
</p>
				</div>
			</div>
		</div>
	</div>
</section>
<?php }else{ ?>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
	<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
	<?php }?>
	<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
		<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
	<?php }?>
	<?php if ($_smarty_tpl->getVariable('newserverversion')->value!==true&&!empty($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_version'])){?>
		<div class="alert alert-warning"><?php echo $_smarty_tpl->getVariable('lang')->value['serverupdateav'];?>
<?php echo $_smarty_tpl->getVariable('newserverversion')->value;?>
</div>
	<?php }?>
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['channel'];?>
</h3>
			</div>
			<div class="box-body">
				<table class="table">
					<tr> 
						<th class="text-center" width="10%"><?php echo $_smarty_tpl->getVariable('lang')->value['id'];?>
</th>
						<th class="text-center" width="10%"><?php echo $_smarty_tpl->getVariable('lang')->value['pid'];?>
</th>
						<th><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
</th>
						<th width="38%"></th>
					</tr>
				<?php if (!empty($_smarty_tpl->getVariable('channellist')->value)){?>
					<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channellist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<tr>
						<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
</td>
						<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['pid'];?>
</td>
						<td style="vertical-align: middle;"><?php echo $_smarty_tpl->tpl_vars['value']->value['channel_name'];?>
</td>
						<td style="vertical-align: middle;" class="no-padding text-right">
							<!-- <a class="btn btn-default btn-flat btn-sm no-margin" href="#" onclick="oeffnefenster('site/filebrowser.php?sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;cid=<?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
')"><?php echo $_smarty_tpl->getVariable('lang')->value['filelist'];?>
</a> -->
							<a class="btn btn-info btn-flat btn-sm no-margin" href="index.php?site=channeleditperm&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;cid=<?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['editperms'];?>
</a>
							<a class="btn btn-warning btn-flat btn-sm no-margin" href="index.php?site=channeledit&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;cid=<?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['channeledit'];?>
</a>
							<a class="btn btn-success btn-flat btn-sm no-margin" href="index.php?site=channelview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;cid=<?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['channelview'];?>
</a>
							<form method="post" style="display: inline;" action="index.php?site=channel&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
								<input type="hidden" name="cid" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
" />
							<?php if ($_smarty_tpl->tpl_vars['value']->value['total_clients']>0){?>
								<input type="hidden" name="force" value="1" />
							<?php }?>
						<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_delete_permanent'])&&$_smarty_tpl->tpl_vars['value']->value['channel_flag_permanent']==1||$_smarty_tpl->getVariable('permoverview')->value['b_channel_delete_permanent']==1&&$_smarty_tpl->tpl_vars['value']->value['channel_flag_permanent']==1){?>
							<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_delete_flag_force'])||$_smarty_tpl->tpl_vars['value']->value['total_clients']==0&&$_smarty_tpl->getVariable('permoverview')->value['b_channel_delete_flag_force']==0||$_smarty_tpl->tpl_vars['value']->value['total_clients']>=0&&$_smarty_tpl->getVariable('permoverview')->value['b_channel_delete_flag_force']==1){?>
								<input type="submit" class="btn btn-sm btn-danger btn-flat no-margin" name="delete" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
" onclick="return confirm('<?php echo $_smarty_tpl->getVariable('lang')->value['deletemsgchannel'];?>
')" />
							<?php }?>
						<?php }?>
						<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_delete_semi_permanent'])&&$_smarty_tpl->tpl_vars['value']->value['channel_flag_semi_permanent']==1||$_smarty_tpl->getVariable('permoverview')->value['b_channel_delete_semi_permanent']==1&&$_smarty_tpl->tpl_vars['value']->value['channel_flag_semi_permanent']==1){?>
							<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_delete_flag_force'])||$_smarty_tpl->tpl_vars['value']->value['total_clients']==0&&$_smarty_tpl->getVariable('permoverview')->value['b_channel_delete_flag_force']==0||$_smarty_tpl->tpl_vars['value']->value['total_clients']>=0&&$_smarty_tpl->getVariable('permoverview')->value['b_channel_delete_flag_force']==1){?>
								<input type="submit" class="btn btn-sm btn-danger btn-flat no-margin" name="delete" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
" onclick="return confirm('<?php echo $_smarty_tpl->getVariable('lang')->value['deletemsgchannel'];?>
')" />
							<?php }?>
						<?php }?>
						<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_delete_temporary'])&&$_smarty_tpl->tpl_vars['value']->value['channel_flag_permanent']==0&&$_smarty_tpl->tpl_vars['value']->value['channel_flag_semi_permanent']==0||$_smarty_tpl->getVariable('permoverview')->value['b_channel_delete_temporary']==1&&$_smarty_tpl->tpl_vars['value']->value['channel_flag_permanent']==0&&$_smarty_tpl->tpl_vars['value']->value['channel_flag_semi_permanent']==0){?>
							<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_delete_flag_force'])||$_smarty_tpl->tpl_vars['value']->value['total_clients']==0&&$_smarty_tpl->getVariable('permoverview')->value['b_channel_delete_flag_force']==0||$_smarty_tpl->tpl_vars['value']->value['total_clients']>=0&&$_smarty_tpl->getVariable('permoverview')->value['b_channel_delete_flag_force']==1){?>
								<input type="submit" class="btn btn-sm btn-danger btn-flat no-margin" name="delete" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
" onclick="return confirm('<?php echo $_smarty_tpl->getVariable('lang')->value['deletemsgchannel'];?>
')" />
							<?php }?>
						<?php }?>
							</form>
						</td>
					</tr>
					<?php }} ?>
				<?php }?>
				</table>
			</div>
		</div>
	<?php }?>
	</div>
</section>
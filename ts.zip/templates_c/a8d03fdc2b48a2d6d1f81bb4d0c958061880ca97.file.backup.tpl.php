<?php /* Smarty version Smarty3rc4, created on 2020-11-06 14:42:16
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/backup.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7204316855fa560c8109e93-43716883%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a8d03fdc2b48a2d6d1f81bb4d0c958061880ca97' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/backup.tpl',
      1 => 1513638412,
    ),
  ),
  'nocache_hash' => '7204316855fa560c8109e93-43716883',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include '/home/victoryf/public_html/ts3panel/libs/Smarty/libs/plugins/modifier.date_format.php';
?><section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
	<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
	<?php }?>
	<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
		<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
	<?php }?>
		<div class="box box-warning">
			<div class="box-body">
				<p><?php echo $_smarty_tpl->getVariable('lang')->value['chanbackdesc'];?>
</p>
			</div>	
		</div>
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['chanbackups'];?>
</h3>
			</div>
			<div class="box-body">
				<table class="table table-striped">
					<tr>
						<th width="30%" class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['created'];?>
</th>
						<th width="30%" class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['server'];?>
</th>
						<th></th>
					</tr>
					<?php if (isset($_smarty_tpl->getVariable('files')->value[0])&&!empty($_smarty_tpl->getVariable('files')->value[0])){?>
						<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('files')->value[0]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
							<?php if ($_smarty_tpl->getVariable('serverhost')->value===true&&$_smarty_tpl->getVariable('hoststatus')->value===false&&$_smarty_tpl->tpl_vars['value']->value['server']==$_smarty_tpl->getVariable('getserverip')->value||$_smarty_tpl->getVariable('serverhost')->value===false||$_smarty_tpl->getVariable('hoststatus')->value===true){?>
					<tr>
						<td style="vertical-align: middle;" class="text-center"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['value']->value['timestamp'],"%d.%m.%Y - %H:%M:%S");?>
</td>
						<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
</td>
						<td style="vertical-align: middle;" class="text-center no-padding">
							<a href="#" class="btn btn-info btn-sm btn-flat" onClick="oeffnefenster('site/chanbackupview.php?backupid=<?php echo $_smarty_tpl->tpl_vars['value']->value['timestamp'];?>
&amp;fileport=<?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
', '<?php echo $_smarty_tpl->getVariable('lang')->value['view'];?>
');"><?php echo $_smarty_tpl->getVariable('lang')->value['view'];?>
</a>
							<form style="display: inline;" method="post" action="index.php?site=backup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
								<input type="hidden" name="backupid" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['timestamp'];?>
" />
								<input type="hidden" name="fileport" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
" />
								<input class="btn btn-flat btn-sm btn-success" type="submit" name="deploy" value="<?php echo $_smarty_tpl->getVariable('lang')->value['deploy'];?>
" />
							</form>
							<form style="display: inline;" method="post" action="index.php?site=backup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
								<input type="hidden" name="backupid" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['timestamp'];?>
" />
								<input type="hidden" name="fileport" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
" />
								<input class="btn btn-flat btn-sm btn-danger" type="submit" name="delete" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
" />
							</form>
						</td>
					</tr>
							<?php }?>
						<?php }} ?>
					<?php }else{ ?>
					<tr>
						<td colspan="3" class="text-center">No Backups found!</td>
					</tr>
					<?php }?>
				</table>
			</div>
		</div>
<?php if ($_smarty_tpl->getVariable('serverhost')->value==true&&$_smarty_tpl->getVariable('hoststatus')->value==true||$_smarty_tpl->getVariable('serverhost')->value==false){?>
		<div class="box box-info">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['host'];?>
 <?php echo $_smarty_tpl->getVariable('lang')->value['chanbackups'];?>
</h3>
			</div>
			<div class="box-body">
				<table class="table table-striped">
					<tr>
						<th width="30%" class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['created'];?>
</th>
						<th width="30%" class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['server'];?>
</th>
						<th></th>
					</tr>
					<?php if (isset($_smarty_tpl->getVariable('files')->value[1])&&!empty($_smarty_tpl->getVariable('files')->value[1])){?>
						<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('files')->value[1]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<tr>
						<td style="vertical-align: middle;" class="text-center"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['value']->value['timestamp'],"%d.%m.%Y - %H:%M:%S");?>
</td>
						<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
</td>
						<td style="vertical-align: middle;" class="text-center no-padding">
							<a href="#" class="btn btn-flat btn-sm btn-info" onClick="oeffnefenster('site/chanbackupview.php?backupid=<?php echo $_smarty_tpl->tpl_vars['value']->value['timestamp'];?>
&amp;fileport=<?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
&amp;hostbackup=1', '<?php echo $_smarty_tpl->getVariable('lang')->value['view'];?>
');"><?php echo $_smarty_tpl->getVariable('lang')->value['view'];?>
</a>
							<form style="display: inline;" method="post" action="index.php?site=backup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
								<input type="hidden" name="hostbackup" value="1" />
								<input type="hidden" name="backupid" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['timestamp'];?>
" />
								<input type="hidden" name="fileport" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
" />
								<input class="btn btn-flat btn-sm btn-success" type="submit" name="deploy" value="<?php echo $_smarty_tpl->getVariable('lang')->value['deploy'];?>
" />
							</form>
							<form style="display: inline;" method="post" action="index.php?site=backup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
								<input type="hidden" name="hostbackup" value="1" />
								<input type="hidden" name="backupid" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['timestamp'];?>
" />
								<input type="hidden" name="fileport" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['server'];?>
" />
								<input class="btn btn-flat btn-sm btn-danger" type="submit" name="delete" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
" />
							</form>
						</td>
					</tr>
						<?php }} ?>
					<?php }else{ ?>
					<tr>
						<td colspan="3" class="text-center">No Backups found!</td>
					</tr>
					<?php }?>
				</table>
			</div>
		</div>
<?php }?>
		<div class="box box-success">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['createchanbackup'];?>
</h3>
			</div>
			<div class="box-body">
				<br />
				<div class="row">
					<div class="col-md-6">
						<form style="display: inline;" method="post" action="index.php?site=backup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
							<input class="btn btn-flat btn-block btn-primary" type="submit" name="create" value="<?php echo $_smarty_tpl->getVariable('lang')->value['create'];?>
" />
						</form>
					</div>
					<div class="col-md-6">
					<?php if ($_smarty_tpl->getVariable('serverhost')->value==true&&$_smarty_tpl->getVariable('hoststatus')->value==true||$_smarty_tpl->getVariable('serverhost')->value==false){?>
						<form style="display: inline;" method="post" action="index.php?site=backup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
							<input type="hidden" name="hostbackup" value="1" />
							<input class="btn btn-flat btn-block btn-info" type="submit" name="create" value="<?php echo $_smarty_tpl->getVariable('lang')->value['host'];?>
 <?php echo $_smarty_tpl->getVariable('lang')->value['create'];?>
" />
						</form>
					<?php }?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
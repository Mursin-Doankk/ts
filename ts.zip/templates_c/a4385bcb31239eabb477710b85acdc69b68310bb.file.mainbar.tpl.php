<?php /* Smarty version Smarty3rc4, created on 2018-02-05 01:47:12
         compiled from "C:\localhost\www\Ts3WebPanel\gelistir2\templates/mrstipfan/mainbar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:102265a77b7a01385c9-97792820%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a4385bcb31239eabb477710b85acdc69b68310bb' => 
    array (
      0 => 'C:\\localhost\\www\\Ts3WebPanel\\gelistir2\\templates/mrstipfan/mainbar.tpl',
      1 => 1513634812,
    ),
  ),
  'nocache_hash' => '102265a77b7a01385c9-97792820',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_smarty_tpl->getVariable('loginstatus')->value===true){?>
	<li class="header"><?php echo $_smarty_tpl->getVariable('lang')->value['server'];?>
</li>
<?php if ($_smarty_tpl->getVariable('hoststatus')->value===true){?>
	<li><a href="index.php?site=server"><i class="mdi mdi-server mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['serverlist'];?>
</span></a></li>
<?php }?>
<?php if (!isset($_smarty_tpl->getVariable('sid')->value)&&$_smarty_tpl->getVariable('hoststatus')->value===true){?>
	<li><a href="index.php?site=createserver"><i class="mdi mdi-server-plus mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['createserver'];?>
</span></a></li>
	<li><a href="index.php?site=servertraffic"><i class="mdi mdi-server-network mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['instancetraffic'];?>
</span></a></li>
	<li><a href="index.php?site=instanceedit"><i class="mdi mdi-pencil mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['instanceedit'];?>
</span></a></li>
	<li><a href="index.php?site=logview"><i class="mdi mdi-format-list-bulleted mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['logview'];?>
</span></a></li>
	<li><a href="index.php?site=iserverbackup"><i class="mdi mdi-backup-restore mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['instancebackup'];?>
</span></a></li>
<?php }?>
<?php if (isset($_smarty_tpl->getVariable('sid')->value)){?>
	<li><a href="index.php?site=serverview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-information-variant mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['serverview'];?>
</span></a></li>
	<li><a href="index.php?site=servertraffic&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-server-network mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['virtualtraffic'];?>
</span></a></li>
	<li><a href="index.php?site=serveredit&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-server-edit mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['serveredit'];?>
</span></a></li>
	<li><a href="index.php?site=temppw&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-lock mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['temppw'];?>
</span></a></li>
	<li><a href="index.php?site=fileupload&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-upload mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['iconupload'];?>
</span></a></li>
	<li><a href="index.php?site=logview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-format-list-bulleted mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['logview'];?>
</span></a></li>
	<li><a href="index.php?site=filelist&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-file-multiple mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['filelist'];?>
</span></a></li>
	<li><a href="javascript:oeffnefenster('site/interactive.php?sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;action=action', '<?php echo $_smarty_tpl->getVariable('lang')->value['massaction'];?>
');"><i class="mdi mdi-checkbox-multiple-marked mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['massaction'];?>
</span></a></li>
	<li class="header"><?php echo $_smarty_tpl->getVariable('lang')->value['channel'];?>
</li>
	<li><a href="index.php?site=channel&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-comment-multiple-outline mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['channellist'];?>
</span></a></li>
<?php if (isset($_smarty_tpl->getVariable('cid')->value)){?>
	<li><a href="index.php?site=channelview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;cid=<?php echo $_smarty_tpl->getVariable('cid')->value;?>
"><i class="mdi mdi-comment-alert-outline mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['channelview'];?>
</span></a></li>
<?php }?>
<?php if (isset($_smarty_tpl->getVariable('cid')->value)){?>
	<li><a href="index.php?site=channeledit&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;cid=<?php echo $_smarty_tpl->getVariable('cid')->value;?>
"><i class="mdi mdi-comment-processing-outline mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['channeledit'];?>
</span></a></li>
<?php }?>
	<li><a href="index.php?site=createchannel&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-comment-plus-outline mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['createchannel'];?>
</span></a></li>
	<li class="header"><?php echo $_smarty_tpl->getVariable('lang')->value['clients'];?>
</li>
	<li><a href="index.php?site=counter&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-account-multiple-star mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['clientcounter'];?>
</span></a></li>
	<li><a href="index.php?site=clients&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-account-multiple mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['clientlist'];?>
</span></a></li>
	<li><a href="index.php?site=complainlist&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-account-alert mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['complainlist'];?>
</span></a></li>
	<li><a href="index.php?site=chanclienteditperm&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-comment-account-outline mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['chanclientperms'];?>
</span></a></li>
	<li><a href="index.php?site=clientcleaner&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-account-multiple-minus mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['clientcleaner'];?>
</span></a></li>
	<li class="header"><?php echo $_smarty_tpl->getVariable('lang')->value['bans'];?>
</li>
	<li><a href="index.php?site=banlist&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-account-multiple-off mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['banlist'];?>
</span></a></li>
	<li><a href="index.php?site=banadd&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-account-off-plus mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['addban'];?>
</span></a></li>
	<li class="header"><?php echo $_smarty_tpl->getVariable('lang')->value['groups'];?>
</li>
	<li><a href="index.php?site=sgroups&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-server-account mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['servergroups'];?>
</span></a></li>
	<li><a href="index.php?site=sgroupadd&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-server-account-plus mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['addservergroup'];?>
</span></a></li>
	<li><a href="index.php?site=cgroups&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-comment-multiple-account-outline mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['channelgroups'];?>
</span></a></li>
	<li><a href="index.php?site=cgroupadd&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-comment-multiple-account-plus-outline mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['addchannelgroup'];?>
</span></a></li>
	<li class="header"><?php echo $_smarty_tpl->getVariable('lang')->value['token'];?>
</li>
	<li><a href="index.php?site=token&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-key-variant mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['token'];?>
</span></a></li>
	<li class="header"><?php echo $_smarty_tpl->getVariable('lang')->value['backup'];?>
</li>
	<li><a href="index.php?site=backup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-comment-download-outline mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['chanbackups'];?>
</span></a></li>
	<li><a href="index.php?site=serverbackup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-server-download mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['serverbackups'];?>
</span></a></li>
	<li><a href="index.php?site=permexport&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-format-section-download mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['permexport'];?>
</span></a></li>
	<li><a href="index.php?site=clientsexport&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-account-multiple-download mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['clientsexport'];?>
</span></a></li>
	<li><a href="index.php?site=bansexport&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-account-off-download mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['bansexport'];?>
</span></a></li>
	<li class="header"><?php echo $_smarty_tpl->getVariable('lang')->value['console'];?>
</li>
	<li><a href="index.php?site=console&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><i class="mdi mdi-console-line mdi-lg"></i> <span><?php echo $_smarty_tpl->getVariable('lang')->value['queryconsole'];?>
</span></a></li>
<?php }?>
<?php }?>
<?php /* Smarty version Smarty3rc4, created on 2020-11-06 16:52:11
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/cgroups.tpl" */ ?>
<?php /*%%SmartyHeaderCode:18255864475fa57f3b3ac564-76796921%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8a83e02b9655755961527d96cbe6de752ee8f55c' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/cgroups.tpl',
      1 => 1513638412,
    ),
  ),
  'nocache_hash' => '18255864475fa57f3b3ac564-76796921',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_channelgroup_list'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_channelgroup_list'])){?>
<section class="content container-fluid">
	<div class="row">
		<div class="col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4">
			<div class="box box-danger">
				<div class="box-header"><h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
</h3></div>
				<div class="box-body">
					<p class="lead"><?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>
</p>
				</div>
			</div>
		</div>
	</div>
</section>
<?php }else{ ?>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
		<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
		<?php }?>
		<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
		<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
		<?php }?>
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['channelgroups'];?>
</h3>
			</div>
			<div class="box-body">
				<table class="table table-striped">
					<tr>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['id'];?>
</th>
						<th><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
</th>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['type'];?>
</th>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['iconid'];?>
</th>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['savedb'];?>
</th>
						<th></th>
					</tr>
			<?php if (!empty($_smarty_tpl->getVariable('channelgroups')->value)){?>
				<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channelgroups')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<tr>
						<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
</td>
						<td style="vertical-align: middle;" class="no-padding">
							<form method="post" action="index.php?site=cgroups&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;cgid=<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
">
								<div class="col-md-8 no-padding">
									<input type="text" name="name" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
" class="form-control" />
								</div>
								<div class="col-md-4 no-padding">
									<input class="btn btn-primary btn-flat btn-block" type="submit" name="sendname" value="<?php echo $_smarty_tpl->getVariable('lang')->value['rename'];?>
" />
								</div>
							</form>
						</td>
						<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['type'];?>
</td>
						<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['iconid'];?>
</td>
						<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['savedb'];?>
</td>
						<td style="vertical-align: middle;" class="text-right no-padding">
						<?php if ($_smarty_tpl->tpl_vars['value']->value['type']!='0'){?>
							<a class="btn btn-sm btn-info btn-flat no-margin" href="index.php?site=cgroupclients&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;cgid=<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['clients'];?>
</a>
						<?php }?>
							<a class="btn btn-sm btn-warning btn-flat no-margin" href="index.php?site=cgroupeditperm&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;cgid=<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['editperms'];?>
</a>
						<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_channelgroup_delete'])||$_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_channelgroup_delete']==1){?>
							<form style="display: inline;" method="post" action="index.php?site=cgroups&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;cgid=<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
">
								<input type="submit" class="btn btn-sm btn-danger btn-flat" name="delgroup" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
" onclick="return confirm('<?php echo $_smarty_tpl->getVariable('lang')->value['deletemsgchannelgroup'];?>
')" />
							</form>
						<?php }?>
						</td>
					</tr>
				<?php }} ?>
			<?php }?>
				</table>
			</div>
		</div>
	</div>
</section>
<?php }?>
<?php /* Smarty version Smarty3rc4, created on 2020-11-06 16:54:31
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/clientsexport.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3926639785fa57fc7649426-75947213%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8d3ff7182307b458408e2e5467027bc50339ef00' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/clientsexport.tpl',
      1 => 1513638412,
    ),
  ),
  'nocache_hash' => '3926639785fa57fc7649426-75947213',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['clientsexport'];?>
</h3>
			</div>
			<div class="box-body">
				<p><?php echo $_smarty_tpl->getVariable('lang')->value['clientsexportdesc'];?>
</p>
				<form method="post" action="site/clientsexport.php" target="_blank">
					<input type="hidden" name="sid" value="<?php echo $_smarty_tpl->getVariable('sid')->value;?>
" />
					<input class="btn btn-primary btn-flat btn-block" type="submit" name="give" value="<?php echo $_smarty_tpl->getVariable('lang')->value['clientsexport'];?>
" />					
				</form>
			</div>
		</div>
	</div>
</section>
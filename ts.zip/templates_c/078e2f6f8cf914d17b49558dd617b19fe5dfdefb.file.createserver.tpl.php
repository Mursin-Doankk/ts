<?php /* Smarty version Smarty3rc4, created on 2020-11-06 16:54:48
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/createserver.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9241644395fa57fd8c9e031-42692084%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '078e2f6f8cf914d17b49558dd617b19fe5dfdefb' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/createserver.tpl',
      1 => 1517802803,
    ),
  ),
  'nocache_hash' => '9241644395fa57fd8c9e031-42692084',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding" style="position: relative;">
<?php if ($_smarty_tpl->getVariable('hoststatus')->value===false&&$_smarty_tpl->getVariable('serverhost')->value===true){?>
	<div class="alert alert-warning"><?php echo $_smarty_tpl->getVariable('lang')->value['nohoster'];?>
</div>
<?php }else{ ?>
<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
	<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
<?php }?>
<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
	<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
<?php }?>
<?php if (!isset($_POST['createserver'])||!empty($_smarty_tpl->getVariable('error')->value)){?>
	<form id="createserver" method="post" action="index.php?site=createserver">
		<input type="hidden" name="createserver">
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['createnewserver'];?>
<br /><small class="no-br"><?php echo $_smarty_tpl->getVariable('lang')->value['createserverdesc'];?>
</small></h3>
			</div>
			<div class="box-body">
				<div id="smartwizard">
					<ul>
						<li><a href="#step-1"><?php echo $_smarty_tpl->getVariable('lang')->value['basics'];?>
</a></li>
						<li><a href="#step-2"><?php echo $_smarty_tpl->getVariable('lang')->value['autoban'];?>
</a></li>
						<li><a href="#step-3"><?php echo $_smarty_tpl->getVariable('lang')->value['host'];?>
</a></li>
						<li><a href="#step-4"><?php echo $_smarty_tpl->getVariable('lang')->value['antiflood'];?>
</a></li>
						<li><a href="#step-5"><?php echo $_smarty_tpl->getVariable('lang')->value['transfers'];?>
</a></li>
						<li><a href="#step-6"><?php echo $_smarty_tpl->getVariable('lang')->value['logs'];?>
</a></li>
					</ul>
					<div>
						<div id="step-1" class="">
							<div class="form-group">
								<label for="new_virtualserver_name"><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
: </label>
								<input type="text" class="form-control" id="new_virtualserver_name" name="newsettings[virtualserver_name]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['name'];?>
" required />
							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="new_virtualserver_port"><?php echo $_smarty_tpl->getVariable('lang')->value['port'];?>
:</label>
										<input type="text" class="form-control" id="new_virtualserver_port" name="newsettings[virtualserver_port]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['port'];?>
" />
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="new_virtualserver_min_client_version"><?php echo $_smarty_tpl->getVariable('lang')->value['minclientversion'];?>
:</label>
										<input type="number" step="1" min="0" class="form-control" id="new_virtualserver_min_client_version" name="newsettings[virtualserver_min_client_version]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['minclientversion'];?>
"/>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label for="new_virtualserver_welcomemessage"><?php echo $_smarty_tpl->getVariable('lang')->value['welcomemsg'];?>
:</label>
								<input type="text" class="form-control" id="new_virtualserver_welcomemessage" name="newsettings[virtualserver_welcomemessage]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['welcomemsg'];?>
"/>
							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="new_virtualserver_maxclients"><?php echo $_smarty_tpl->getVariable('lang')->value['maxclients'];?>
:</label>
										<input type="number" step="1" min="1" class="form-control" id="new_virtualserver_maxclients" name="newsettings[virtualserver_maxclients]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['maxclients'];?>
"/>
									</div>		                	
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="new_virtualserver_reserved_slots"><?php echo $_smarty_tpl->getVariable('lang')->value['maxreservedslots'];?>
:</label>
										<input type="number" step="1" min="0" class="form-control" id="new_virtualserver_reserved_slots" name="newsettings[virtualserver_reserved_slots]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['reservedslots'];?>
"/>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="new_virtualserver_weblist_enabled"><?php echo $_smarty_tpl->getVariable('lang')->value['showonweblist'];?>
:</label>
										<select class="form-control" name="newsettings[virtualserver_weblist_enabled]" id="new_virtualserver_weblist_enabled">
											<option value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_weblist_enabled']==1){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</option>
											<option value="0" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_weblist_enabled']==0){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</option>
										</select>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="new_virtualserver_password"><?php echo $_smarty_tpl->getVariable('lang')->value['password'];?>
:</label>
										<input type="text" class="form-control" id="new_virtualserver_password" name="newsettings[virtualserver_password]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['password'];?>
"/>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="new_virtualserver_needed_identity_security_level"><?php echo $_smarty_tpl->getVariable('lang')->value['securitylevel'];?>
:</label>
										<input type="number" step="1" min="1" class="form-control" id="new_virtualserver_needed_identity_security_level" name="newsettings[virtualserver_needed_identity_security_level]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['securitylvl'];?>
"/>
									</div>		                	
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="new_virtualserver_min_clients_in_channel_before_forced_silence"><?php echo $_smarty_tpl->getVariable('lang')->value['minclientschan'];?>
:</label>
										<input type="number" step="1" min="1" class="form-control" id="new_virtualserver_min_clients_in_channel_before_forced_silence" name="newsettings[virtualserver_min_clients_in_channel_before_forced_silence]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['forcesilence'];?>
"/>
									</div>
								</div>
							</div>
						</div>
						<div id="step-2" class="">
							<div class="form-group">
								<label for="new_virtualserver_complain_autoban_count"><?php echo $_smarty_tpl->getVariable('lang')->value['autobancount'];?>
:</label>
								<input type="text" class="form-control" id="new_virtualserver_complain_autoban_count" name="newsettings[virtualserver_complain_autoban_count]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['autobancount'];?>
"/>
							</div>
							<div class="form-group">
								<label for="new_virtualserver_complain_autoban_time"><?php echo $_smarty_tpl->getVariable('lang')->value['autobantime'];?>
:</label>
								<div class="input-group">
									<input type="text" class="form-control" id="new_virtualserver_complain_autoban_time" name="newsettings[virtualserver_complain_autoban_time]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['autobantime'];?>
"/>
									<span class="input-group-addon"><?php echo $_smarty_tpl->getVariable('lang')->value['seconds'];?>
</span>
								</div>
							</div>
							<div class="form-group">
								<label for="new_virtualserver_complain_remove_time"><?php echo $_smarty_tpl->getVariable('lang')->value['removetime'];?>
:</label>
								<div class="input-group">
									<input type="text" class="form-control" id="new_virtualserver_complain_remove_time" name="newsettings[virtualserver_complain_remove_time]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['removetime'];?>
"/>
									<span class="input-group-addon"><?php echo $_smarty_tpl->getVariable('lang')->value['seconds'];?>
</span>
								</div>
							</div>	
						</div>
						<div id="step-3" class="">
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="new_virtualserver_hostmessage"><?php echo $_smarty_tpl->getVariable('lang')->value['hostmessage'];?>
:</label>
										<input type="text" class="form-control" id="new_virtualserver_hostmessage" name="newsettings[virtualserver_hostmessage]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['hostmsg'];?>
"/>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="new_virtualserver_hostmessage_mode"><?php echo $_smarty_tpl->getVariable('lang')->value['hostmessageshow'];?>
:</label>
										<select class="form-control" id="new_virtualserver_hostmessage_mode" name="newsettings[virtualserver_hostmessage_mode]">
											<option value="0" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']==0){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['nomessage'];?>
</option>
											<option value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']==1){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['showmessagelog'];?>
</option>
											<option value="2" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']==2){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['showmodalmessage'];?>
</option>
											<option value="3" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']==3){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['modalandexit'];?>
</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-5">
									<div class="form-group">
										<label for="new_virtualserver_hostbanner_url"><?php echo $_smarty_tpl->getVariable('lang')->value['hosturl'];?>
:</label>
										<input type="text" class="form-control" id="new_virtualserver_hostbanner_url" name="newsettings[virtualserver_hostbanner_url]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['hosturl'];?>
"/>
									</div>
								</div>
								<div class="col-md-5">
									<div class="form-group">
										<label for="new_virtualserver_hostbanner_gfx_url"><?php echo $_smarty_tpl->getVariable('lang')->value['hostbannerurl'];?>
:</label>
										<input type="text" class="form-control" id="new_virtualserver_hostbanner_gfx_url" name="newsettings[virtualserver_hostbanner_gfx_url]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['hostbannerurl'];?>
"/>
									</div>
								</div>
								<div class="col-md-2">
									<div class="form-group">
										<label for="new_virtualserver_hostbanner_gfx_interval"><?php echo $_smarty_tpl->getVariable('lang')->value['hostbannerintval'];?>
:</label>
										<input type="number" step="1" min="0" max="60" class="form-control" id="new_virtualserver_hostbanner_gfx_interval" name="newsettings[virtualserver_hostbanner_gfx_interval]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['hostbannerint'];?>
"/>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-4">
									<div class="form-group no-margin">
										<label for="new_virtualserver_hostbutton_gfx_url"><?php echo $_smarty_tpl->getVariable('lang')->value['hostbuttongfx'];?>
:</label>
										<input type="text" class="form-control" id="new_virtualserver_hostbutton_gfx_url" name="newsettings[virtualserver_hostbutton_gfx_url]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['hostbuttongfx'];?>
"/>
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group no-margin">
										<label for="new_virtualserver_hostbutton_tooltip"><?php echo $_smarty_tpl->getVariable('lang')->value['hostbuttontooltip'];?>
:</label>
										<input type="text" class="form-control" id="new_virtualserver_hostbutton_tooltip" name="newsettings[virtualserver_hostbutton_tooltip]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['hostbuttontip'];?>
"/>
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group no-margin">
										<label for="new_virtualserver_hostbutton_url"><?php echo $_smarty_tpl->getVariable('lang')->value['hostbuttonurl'];?>
:</label>
										<input type="text" class="form-control" id="new_virtualserver_hostbutton_url" name="newsettings[virtualserver_hostbutton_url]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['hostbuttonurl'];?>
"/>
									</div>
								</div>
							</div>		                		
						</div>
						<div id="step-4" class="">
							<div class="form-group">
								<label for="new_virtualserver_antiflood_points_tick_reduce"><?php echo $_smarty_tpl->getVariable('lang')->value['pointstickreduce'];?>
:</label>
								<input type="text" class="form-control" id="new_virtualserver_antiflood_points_tick_reduce" name="newsettings[virtualserver_antiflood_points_tick_reduce]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['pointstickreduce'];?>
"/>
							</div>
							<div class="form-group">
								<label for="new_virtualserver_antiflood_points_needed_command_block"><?php echo $_smarty_tpl->getVariable('lang')->value['pointsneededblockcmd'];?>
:</label>
								<input type="text" class="form-control" id="new_virtualserver_antiflood_points_needed_command_block" name="newsettings[virtualserver_antiflood_points_needed_command_block]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['pointsneededblockcmd'];?>
"/>
							</div>
							<div class="form-group">
								<label for="new_virtualserver_antiflood_points_needed_ip_block"><?php echo $_smarty_tpl->getVariable('lang')->value['pointsneededblockip'];?>
:</label>
								<input type="text" class="form-control" id="new_virtualserver_antiflood_points_needed_ip_block" name="newsettings[virtualserver_antiflood_points_needed_ip_block]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['pointsneededblockip'];?>
"/>
							</div>
						</div>
						<div id="step-5" class="">
							<div class="form-group">
								<label for="new_virtualserver_max_upload_total_bandwidth"><?php echo $_smarty_tpl->getVariable('lang')->value['upbandlimit'];?>
:</label>
								<div class="input-group">
									<input type="text" class="form-control" id="new_virtualserver_max_upload_total_bandwidth" name="newsettings[virtualserver_max_upload_total_bandwidth]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['uploadbandwidthlimit'];?>
"/> 
									<span class="input-group-addon">Byte/s</span>
								</div>
							</div>
							<div class="form-group">
								<label for="new_virtualserver_upload_quota"><?php echo $_smarty_tpl->getVariable('lang')->value['uploadquota'];?>
:</label>
								<div class="input-group">
									<input type="text" class="form-control" id="new_virtualserver_upload_quota" name="newsettings[virtualserver_upload_quota]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['uploadquota'];?>
"/> 
									<span class="input-group-addon">MiB</span>
								</div>
							</div>
							<div class="form-group">
								<label for="new_virtualserver_max_download_total_bandwidth"><?php echo $_smarty_tpl->getVariable('lang')->value['downbandlimit'];?>
:</label>
								<div class="input-group">
									<input type="text" class="form-control" id="new_virtualserver_max_download_total_bandwidth" name="newsettings[virtualserver_max_download_total_bandwidth]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['downloadbandwidthlimit'];?>
"/> 
									<span class="input-group-addon">Byte/s</span>
								</div>
							</div>
							<div class="form-group">
								<label for="new_virtualserver_download_quota"><?php echo $_smarty_tpl->getVariable('lang')->value['downloadquota'];?>
:</label>
								<div class="input-group">
									<input type="text" class="form-control" id="new_virtualserver_download_quota" name="newsettings[virtualserver_download_quota]" value="<?php echo $_smarty_tpl->getVariable('screate_tmp')->value['downloadquota'];?>
"/>
									<span class="input-group-addon">MiB</span>
								</div>
							</div>
						</div>
						<div id="step-6" class="">
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="new_virtualserver_log_client"><?php echo $_smarty_tpl->getVariable('lang')->value['logclient'];?>
:</label>
										<input type="checkbox" id="new_virtualserver_log_client" name="newsettings[virtualserver_log_client]" value="1" <?php if ($_smarty_tpl->getVariable('screate_tmp')->value['virtualserver_log_client']==='1'){?>checked<?php }?> data-toggle="toggle" data-width="100%" data-onstyle="primary" data-offstyle="warning" data-size="small" data-on="<?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
" data-off="<?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
"/>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="new_virtualserver_log_query"><?php echo $_smarty_tpl->getVariable('lang')->value['logquery'];?>
:</label>
										<input type="checkbox" id="new_virtualserver_log_query" name="newsettings[virtualserver_log_query]" value="1" <?php if ($_smarty_tpl->getVariable('screate_tmp')->value['virtualserver_log_query']==='1'){?>checked<?php }?> data-toggle="toggle" data-width="100%" data-onstyle="primary" data-offstyle="warning" data-size="small" data-on="<?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
" data-off="<?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
"/>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="new_virtualserver_log_channel"><?php echo $_smarty_tpl->getVariable('lang')->value['logchannel'];?>
:</label>				
										<input type="checkbox" id="new_virtualserver_log_channel" name="newsettings[virtualserver_log_channel]" value="1" <?php if ($_smarty_tpl->getVariable('screate_tmp')->value['virtualserver_log_channel']==='1'){?>checked<?php }?> data-toggle="toggle" data-width="100%" data-onstyle="primary" data-offstyle="warning" data-size="small" data-on="<?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
" data-off="<?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
"/>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="new_virtualserver_log_permissions"><?php echo $_smarty_tpl->getVariable('lang')->value['logpermissions'];?>
:</label>
										<input type="checkbox" id="new_virtualserver_log_permissions" name="newsettings[virtualserver_log_permissions]" value="1" <?php if ($_smarty_tpl->getVariable('screate_tmp')->value['virtualserver_log_permissions']==='1'){?>checked<?php }?> data-toggle="toggle" data-width="100%" data-onstyle="primary" data-offstyle="warning" data-size="small" data-on="<?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
" data-off="<?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
"/>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="new_virtualserver_log_server"><?php echo $_smarty_tpl->getVariable('lang')->value['logserver'];?>
:</label>
										<input type="checkbox" id="new_virtualserver_log_server" name="newsettings[virtualserver_log_server]" value="1" <?php if ($_smarty_tpl->getVariable('screate_tmp')->value['virtualserver_log_server']==='1'){?>checked<?php }?> data-toggle="toggle" data-width="100%" data-onstyle="primary" data-offstyle="warning" data-size="small" data-on="<?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
" data-off="<?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
"/>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="new_virtualserver_log_filetransfer"><?php echo $_smarty_tpl->getVariable('lang')->value['logfiletransfer'];?>
:</label>
										<input type="checkbox" id="new_virtualserver_log_filetransfer" name="newsettings[virtualserver_log_filetransfer]" value="1" <?php if ($_smarty_tpl->getVariable('screate_tmp')->value['virtualserver_log_filetransfer']==='1'){?>checked<?php }?> data-toggle="toggle" data-width="100%" data-onstyle="primary" data-offstyle="warning" data-size="small" data-on="<?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
" data-off="<?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
"/>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			$(document).ready(function(){
			var btnFinish = $('<inout type="submit"/>').text('<?php echo $_smarty_tpl->getVariable('lang')->value['createserver'];?>
').addClass('btn btn-success btn-flat').on('click', function(e){
					e.preventDefault(); 
					var elmForm = $("#createserver");
					elmForm.validator('validate'); 
					var elmErr = elmForm.find('.has-error');
					if(elmErr && elmErr.length > 0){
						$('.has-error').each(function(key, item){
							var step = $(item).parent('.step-content').attr('id');
							$('a[href="#' +step+ '"]').parent('li').addClass('danger');
						});
						return false;
					}else{
						$('#createserver').submit();
						return false;
					}
				});
				$('#smartwizard').smartWizard({ 
					enableAllSteps: true,
					showStepURLhash: false,
					lang: {
						next:  nextText,
						previous: previousText,
					}
				});
				$('#smartwizard .sw-toolbar-bottom').addClass('no-padding');
				$('#smartwizard .sw-btn-group').append(btnFinish);
				$('#smartwizard .sw-btn-next').addClass('btn-flat');
				$('#smartwizard .sw-btn-prev').addClass('btn-flat'); 

			});   
		</script>
		<input class="btn btn-success btn-flat btn-block" type="submit" name="createserver" value="<?php echo $_smarty_tpl->getVariable('lang')->value['add'];?>
" />
		</form>
<?php }?>
<?php }?>
	</div>
</section>
<?php /* Smarty version Smarty3rc4, created on 2018-02-05 02:15:35
         compiled from "C:\localhost\www\Ts3WebPanel\gelistir2\templates/46/server.tpl" */ ?>
<?php /*%%SmartyHeaderCode:188155a77be47ddc8a4-64855727%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '449cf0ab402f519a3f533befe139d4c5b4cc4b3e' => 
    array (
      0 => 'C:\\localhost\\www\\Ts3WebPanel\\gelistir2\\templates/46/server.tpl',
      1 => 1501419068,
    ),
  ),
  'nocache_hash' => '188155a77be47ddc8a4-64855727',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<section class="content container-fluid">
	<div class="col-lg-10 col-lg-offset-1">
		<?php if ($_smarty_tpl->getVariable('hoststatus')->value===false&&$_smarty_tpl->getVariable('serverhost')->value===true){?>
		<div class="alert alert-warning"><?php echo $_smarty_tpl->getVariable('lang')->value['nohoster'];?>
</div>
		<?php }else{ ?>
		<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
		<?php }?>
		<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
		<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
		<?php }?>
		<div class="box box-border-teal">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['msgtoall'];?>
</h3>
			</div>
			<form class="box-body" method="post" action="index.php?site=server">
				<div class="form-group">
					<textarea type="text" class="form-control resize-vert" name="msgtoall" id="msgtoall"></textarea>
				</div>
				<input class="btn btn-flat bg-teal pull-right" type="submit" name="sendmsg" value="<?php echo $_smarty_tpl->getVariable('lang')->value['send'];?>
" />
			</form>
		</div>

		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['server'];?>
</h3>
			</div>
			<form class="box-body" method="post" name="saction" action="index.php?site=server">
				<?php if (!empty($_smarty_tpl->getVariable('serverlist')->value)){?>
				<p><?php echo $_smarty_tpl->getVariable('serverstats')->value;?>
</p>
				<?php }?>

				<table class="table table-striped">
					<tr>
						<th class="text-center">
							<a class="headlink" href="index.php?site=server&amp;sortby=id&amp;sorttype=<?php if ($_smarty_tpl->getVariable('sortby')->value=='virtualserver_id'&&$_smarty_tpl->getVariable('sorttype')->value==@SORT_ASC){?>desc<?php }else{ ?>asc<?php }?>"><?php echo $_smarty_tpl->getVariable('lang')->value['id'];?>
</a>
						</th>
						<th class="text-center">
							<a class="headlink" href="index.php?site=server&amp;sortby=name&amp;sorttype=<?php if ($_smarty_tpl->getVariable('sortby')->value=='virtualserver_name'&&$_smarty_tpl->getVariable('sorttype')->value==@SORT_ASC){?>desc<?php }else{ ?>asc<?php }?>"><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
</a>
						</th>
						<th class="text-center">
							<a class="headlink" href="index.php?site=server&amp;sortby=port&amp;sorttype=<?php if ($_smarty_tpl->getVariable('sortby')->value=='virtualserver_port'&&$_smarty_tpl->getVariable('sorttype')->value==@SORT_ASC){?>desc<?php }else{ ?>asc<?php }?>"><?php echo $_smarty_tpl->getVariable('lang')->value['port'];?>
</a>
						</th>
						<th class="text-center">
							<a class="headlink" href="index.php?site=server&amp;sortby=status&amp;sorttype=<?php if ($_smarty_tpl->getVariable('sortby')->value=='virtualserver_status'&&$_smarty_tpl->getVariable('sorttype')->value==@SORT_ASC){?>desc<?php }else{ ?>asc<?php }?>"><?php echo $_smarty_tpl->getVariable('lang')->value['status'];?>
</a>
						</th>
						<th class="text-center">
							<a class="headlink" href="index.php?site=server&amp;sortby=uptime&amp;sorttype=<?php if ($_smarty_tpl->getVariable('sortby')->value=='virtualserver_uptime'&&$_smarty_tpl->getVariable('sorttype')->value==@SORT_ASC){?>desc<?php }else{ ?>asc<?php }?>"><?php echo $_smarty_tpl->getVariable('lang')->value['runtime'];?>
</a>
						</th>
						<th class="text-center"><a class="headlink" href="index.php?site=server&amp;sortby=clients&amp;sorttype=<?php if ($_smarty_tpl->getVariable('sortby')->value=='virtualserver_clientsonline'&&$_smarty_tpl->getVariable('sorttype')->value==@SORT_ASC){?>desc<?php }else{ ?>asc<?php }?>"><?php echo $_smarty_tpl->getVariable('lang')->value['clients'];?>
</a>
						</th>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['autostart'];?>
</th>
						<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['options'];?>
</th>
					</tr>
					<?php if (!empty($_smarty_tpl->getVariable('serverlist')->value)){?>
					<tr>
						<th colspan="7">
						</th>
						<th class="no-padding">
							<input class="btn btn-flat btn-primary btn-block" type="submit" name="massaction" value="<?php echo $_smarty_tpl->getVariable('lang')->value['action'];?>
" onclick="return confirm(confirm_action())" />
						</th>
					</tr>
				<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('serverlist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<tr>
						<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
</td>
						<td style="vertical-align: middle;" class="text-center"><a href="index.php?site=serverview&amp;sid=<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_name'];?>
</a></td>
						<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_port'];?>
</td>
						<td style="vertical-align: middle;" class="text-center">
						<?php if ($_smarty_tpl->tpl_vars['value']->value['virtualserver_status']=="online"){?>
							<span class="text-success"><?php echo $_smarty_tpl->getVariable('lang')->value['online'];?>
</span>
						<?php }elseif($_smarty_tpl->tpl_vars['value']->value['virtualserver_status']=="online virtual"){?>
						<span class="onvirtual"><?php echo $_smarty_tpl->getVariable('lang')->value['onlinevirtual'];?>
</span>
						<?php }elseif($_smarty_tpl->tpl_vars['value']->value['virtualserver_status']=="offline"){?>
							<span class="text-danger"><?php echo $_smarty_tpl->getVariable('lang')->value['offline'];?>
</span>
						<?php }?>
						</td>
						<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_uptime'];?>
</td>
						<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_clientsonline'];?>
 / <?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_maxclients'];?>
</td>
						<td style="vertical-align: middle;" class="text-center"><input type="checkbox" name="caction[<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
][auto]" value="1" <?php if ($_smarty_tpl->tpl_vars['value']->value['virtualserver_autostart']==1){?>checked="checked"<?php }?>/></td>
						<td class="text-right no-padding">
							<select class="form-control" id="caction<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
" name="caction[<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
][action]" onchange="confirm_array('<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
', '<?php echo addslashes($_smarty_tpl->tpl_vars['value']->value['virtualserver_name']);?>
', '<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_port'];?>
', '');">
								<option value="false"><?php echo $_smarty_tpl->getVariable('lang')->value['select'];?>
</option>
								<option value="start"><?php echo $_smarty_tpl->getVariable('lang')->value['start'];?>
</option>
								<option value="stop"><?php echo $_smarty_tpl->getVariable('lang')->value['stop'];?>
</option>
								<option value="del"><?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
</option>
							</select>
						</td>
					</tr>
				<?php }} ?>
					<tr>
						<th colspan="7">
						</th>
						<th class="no-padding">
							<input class="btn btn-flat btn-primary btn-block" type="submit" name="massaction" value="<?php echo $_smarty_tpl->getVariable('lang')->value['action'];?>
" onclick="return confirm(confirm_action())" />
						</th>
					</tr>
					<?php }else{ ?>
					<tr><td colspan='8'><p class="lead"><?php echo $_smarty_tpl->getVariable('lang')->value['noserver'];?>
</p></td></tr>
					<?php }?>
				</table>
			</form>
		</div>
		<?php }?>
	</div>
</section>
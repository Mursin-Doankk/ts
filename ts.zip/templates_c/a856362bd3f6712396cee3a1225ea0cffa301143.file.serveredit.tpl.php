<?php /* Smarty version Smarty3rc4, created on 2020-11-06 14:40:41
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/serveredit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7939711265fa56069ae21d8-03449480%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a856362bd3f6712396cee3a1225ea0cffa301143' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/serveredit.tpl',
      1 => 1513638412,
    ),
  ),
  'nocache_hash' => '7939711265fa56069ae21d8-03449480',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<section class="content-header">
	<h1>
		<?php echo $_smarty_tpl->getVariable('lang')->value['virtualserver'];?>
 #<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_id'];?>
 <?php echo $_smarty_tpl->getVariable('lang')->value['editor'];?>

	</h1>
</section>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding" style="position: relative;">
	<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
	<?php }?>
	<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
		<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
	<?php }?>
	<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_password'])||$_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_password']==1){?>
		<div class="col-md-12">
			<div class="box box-border-lime">
				<div class="box-header">
					<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['serverpassword'];?>
</h3>
					<div class="box-tools pull-right">
						<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
					</div>
				</div>
				<div class="box-body">
					<form method="post" action="index.php?site=serveredit&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
						<div class="row">
							<div class="form-group col-xs-12 col-sm-7 col-md-8 col-lg-9">
								<label for="new_virtualserver_password"><?php echo $_smarty_tpl->getVariable('lang')->value['newpassword'];?>
:</label>
								<input type="text" class="form-control" id="new_virtualserver_password" name="newsettings[virtualserver_password]"/>
							</div>
							<div class="form-group col-xs-12 col-sm-5 col-md-4 col-lg-3">
								<label class="hidden-xs">&nbsp;</label>
								<input class="btn btn-flat bg-lime btn-block" type="submit" name="editpw" value="<?php echo $_smarty_tpl->getVariable('lang')->value['send'];?>
" />
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	<?php }?>
		<form method="post" action="index.php?site=serveredit&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
			<div class="col-md-6">
				<div class="box box-primary">
					<div class="box-header">
						<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['basics'];?>
</h3>
						<div class="box-tools pull-right">
							<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
						</div>
					</div>
					<div class="box-body">
						<div class="form-group">
							<label for="new_virtualserver_name"><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_name'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_name'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<input type="text" class="form-control" id="new_virtualserver_name" name="newsettings[virtualserver_name]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_name'];?>
">
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_autostart"><?php echo $_smarty_tpl->getVariable('lang')->value['autostart'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_autostart'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_autostart'])){?>
								&nbps; -
						<?php }else{ ?>
							<select id="new_virtualserver_autostart" class="form-control" name="newsettings[virtualserver_autostart]">
								<option value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_autostart']==1){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</option>
								<option value="0" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_autostart']==0){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</option>
							</select>
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_port"><?php echo $_smarty_tpl->getVariable('lang')->value['port'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_port'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_port'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<input type="number" min="1" max="65535" step="1" class="form-control" id="new_virtualserver_port" name="newsettings[virtualserver_port]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_port'];?>
">
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_min_client_version"><?php echo $_smarty_tpl->getVariable('lang')->value['minclientversion'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_min_client_version'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_min_client_version'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<input type="number" min="1" step="1" class="form-control" id="new_virtualserver_min_client_version" name="newsettings[virtualserver_min_client_version]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_min_client_version'];?>
">
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_welcomemessage"><?php echo $_smarty_tpl->getVariable('lang')->value['welcomemsg'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_welcomemessage'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_welcomemessage'])){?>
							&nbps; -
						<?php }else{ ?>
							<textarea class="form-control resize-vert" name="newsettings[virtualserver_welcomemessage]" id="new_virtualserver_welcomemessage" rows="2"><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_welcomemessage'];?>
</textarea>
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_maxclients"><?php echo $_smarty_tpl->getVariable('lang')->value['maxclients'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_maxclients'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_maxclients'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<input type="number" min="1" max="1024" step="1" class="form-control" id="new_virtualserver_maxclients" name="newsettings[virtualserver_maxclients]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_maxclients'];?>
">
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_reserved_slots"><?php echo $_smarty_tpl->getVariable('lang')->value['maxreservedslots'];?>
:</label></td>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_reserved_slots'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_reserved_slots'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<input type="number" min="1" max="1024" class="form-control" id="new_virtualserver_reserved_slots" name="newsettings[virtualserver_reserved_slots]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_reserved_slots'];?>
">
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_weblist_enabled"><?php echo $_smarty_tpl->getVariable('lang')->value['showonweblist'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_weblist'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_weblist'])){?>
							&nbps; -
						<?php }else{ ?>
							<select class="form-control" name="newsettings[virtualserver_weblist_enabled]" id="new_virtualserver_weblist_enabled">
								<option value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_weblist_enabled']==1){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</option>
								<option value="0" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_weblist_enabled']==0){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</option>
							</select>
						<?php }?>
						</div>
						<div class="form-group">
							<label for="virtualserver_modify_codec_encryption_mode"><?php echo $_smarty_tpl->getVariable('lang')->value['codecencryptionmode'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_codec_encryption_mode'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_codec_encryption_mode'])){?>
							&nbps; -
						<?php }else{ ?>
							<select class="form-control" name="newsettings[virtualserver_codec_encryption_mode]" id="virtualserver_modify_codec_encryption_mode">
								<option value="0" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_codec_encryption_mode']==0){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['codecencryptionmodeindi'];?>
</option>
								<option value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_codec_encryption_mode']==1){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['codecencryptionmodegoff'];?>
</option>
								<option value="2" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_codec_encryption_mode']==2){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['codecencryptionmodegon'];?>
</option>
							</select>
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_password"><?php echo $_smarty_tpl->getVariable('lang')->value['passwordset'];?>
:</label></td>
							<p>
							<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_password'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_password'])){?>
								&nbps; - 
							<?php }else{ ?>
								&nbsp;<?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_flag_password']==1){?><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
<?php }else{ ?> <?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
<?php }?>
							<?php }?>
							</p>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_needed_identity_security_level"><?php echo $_smarty_tpl->getVariable('lang')->value['securitylevel'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_needed_identity_security_level'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_needed_identity_security_level'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<input type="number" min="1" step="1" class="form-control" id="new_virtualserver_needed_identity_security_level" name="newsettings[virtualserver_needed_identity_security_level]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_needed_identity_security_level'];?>
"/>
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_min_clients_in_channel_before_forced_silence"><?php echo $_smarty_tpl->getVariable('lang')->value['minclientschan'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_channel_forced_silence'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_channel_forced_silence'])){?>
							&nbps; - 
						<?php }else{ ?>
							<input type="number" min="1" step="1" class="form-control" id="new_virtualserver_min_clients_in_channel_before_forced_silence" name="newsettings[virtualserver_min_clients_in_channel_before_forced_silence]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_min_clients_in_channel_before_forced_silence'];?>
"/>
						<?php }?>
						</div>
						<div class="form-group">
							<label for="iconid"><?php echo $_smarty_tpl->getVariable('lang')->value['iconid'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_icon_id'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_icon_id'])){?>
							&nbps; - 
						<?php }else{ ?>
							<div class="input-group">
								<input id="iconid" class="form-control" type="number" min="0" step="1" name="newsettings[virtualserver_icon_id]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_icon_id'];?>
" />
								<div class="input-group-addon">									
									<a href="javascript:oeffnefenster('site/showallicons.php?ip=<?php echo $_SESSION['server_ip'];?>
&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;port=<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_port'];?>
', '<?php echo $_smarty_tpl->getVariable('lang')->value['set'];?>
');"><?php echo $_smarty_tpl->getVariable('lang')->value['set'];?>
</a>
								</div>
							</div>
						<?php }?>
						</div>
					</div>
				</div>
				<div class="box box-info"> 
					<div class="box-header">
						<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['host'];?>
</h3>
						<div class="box-tools pull-right">
							<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
						</div>
					</div>
					<div class="box-body">
						<div class="form-group">
							<label for="new_virtualserver_hostmessage"><?php echo $_smarty_tpl->getVariable('lang')->value['hostmessage'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostmessage'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostmessage'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<textarea class="form-control resize-vert" id="new_virtualserver_hostmessage" name="newsettings[virtualserver_hostmessage]" rows="2"><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage'];?>
</textarea>
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_hostmessage_mode"><?php echo $_smarty_tpl->getVariable('lang')->value['hostmessageshow'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostmessage'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostmessage'])){?>
							&nbsp; - 
						<?php }else{ ?>
						<select class="form-control" id="new_virtualserver_hostmessage_mode" name="newsettings[virtualserver_hostmessage_mode]">
							<option value="0" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']==0){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['nomessage'];?>
</option>
							<option value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']==1){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['showmessagelog'];?>
</option>
							<option value="2" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']==2){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['showmodalmessage'];?>
</option>
							<option value="3" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']==3){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['modalandexit'];?>
</option>
						</select>
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_hostbanner_url"><?php echo $_smarty_tpl->getVariable('lang')->value['hosturl'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbanner'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbanner'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<input type="text" class="form-control" id="new_virtualserver_hostbanner_url" name="newsettings[virtualserver_hostbanner_url]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_url'];?>
" />
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_hostbanner_gfx_url"><?php echo $_smarty_tpl->getVariable('lang')->value['hostbannerurl'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbanner'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbanner'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_gfx_url']!=''){?>
							<img style="width:350px" src="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_gfx_url'];?>
" alt="" /><br />
							<?php }?>
							<input type="text" class="form-control" id="new_virtualserver_hostbanner_gfx_url" name="newsettings[virtualserver_hostbanner_gfx_url]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_gfx_url'];?>
" />
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_hostbanner_gfx_interval"><?php echo $_smarty_tpl->getVariable('lang')->value['hostbannerintval'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbanner'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbanner'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<input type="number" max="60" min="0" step="1" class="form-control" id="new_virtualserver_hostbanner_gfx_interval" name="newsettings[virtualserver_hostbanner_gfx_interval]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_gfx_interval'];?>
" />
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_hostbutton_tooltip"><?php echo $_smarty_tpl->getVariable('lang')->value['hostbuttontooltip'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbutton'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbutton'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<input type="text" class="form-control" id="new_virtualserver_hostbutton_tooltip" name="newsettings[virtualserver_hostbutton_tooltip]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbutton_tooltip'];?>
" />
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_hostbutton_gfx_url"><?php echo $_smarty_tpl->getVariable('lang')->value['hostbuttongfx'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbutton'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbutton'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<input type="text" class="form-control" id="new_virtualserver_hostbutton_gfx_url" name="newsettings[virtualserver_hostbutton_gfx_url]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbutton_gfx_url'];?>
" />
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_hostbutton_url"><?php echo $_smarty_tpl->getVariable('lang')->value['hostbuttonurl'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbutton'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbutton'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<input type="text" class="form-control" id="new_virtualserver_hostbutton_url" name="newsettings[virtualserver_hostbutton_url]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbutton_url'];?>
" />
						<?php }?>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div class="box box-border-olive">
					<div class="box-header">
						<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['standardgroups'];?>
</h3>
						<div class="box-tools pull-right">
							<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
						</div>
					</div>
					<div class="box-body">
						<div class="form-group">
							<label for="new_virtualserver_default_server_group"><?php echo $_smarty_tpl->getVariable('lang')->value['servergroup'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_default_servergroup'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_default_servergroup'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<select class="form-control" id="new_virtualserver_default_server_group" name="newsettings[virtualserver_default_server_group]">
							<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('servergroups')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
								<?php if ($_smarty_tpl->tpl_vars['value']->value['type']==1){?>
									<option <?php if ($_smarty_tpl->tpl_vars['value']->value['sgid']==$_smarty_tpl->getVariable('serverinfo')->value['virtualserver_default_server_group']){?>selected="selected"<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['value']->value['sgid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['sgid'];?>
 <?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</option>
								<?php }?>
							<?php }} ?>
							</select>
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_default_channel_group"><?php echo $_smarty_tpl->getVariable('lang')->value['channelgroup'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_default_channelgroup'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_default_channelgroup'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<select class="form-control" id="new_virtualserver_default_channel_group" name="newsettings[virtualserver_default_channel_group]">
							<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channelgroups')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
								<?php if ($_smarty_tpl->tpl_vars['value']->value['type']==1){?>
									<option <?php if ($_smarty_tpl->tpl_vars['value']->value['cgid']==$_smarty_tpl->getVariable('serverinfo')->value['virtualserver_default_channel_group']){?>selected="selected"<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
 <?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</option>
								<?php }?>
							<?php }} ?>
							</select>
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_default_channel_admin_group"><?php echo $_smarty_tpl->getVariable('lang')->value['chanadmingroup'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_default_channeladmingroup'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_default_channeladmingroup'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<select class="form-control" id="new_virtualserver_default_channel_admin_group" name="newsettings[virtualserver_default_channel_admin_group]">
							<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channelgroups')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
								<?php if ($_smarty_tpl->tpl_vars['value']->value['type']==1){?>
									<option <?php if ($_smarty_tpl->tpl_vars['value']->value['cgid']==$_smarty_tpl->getVariable('serverinfo')->value['virtualserver_default_channel_admin_group']){?>selected="selected"<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
 <?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</option>
								<?php }?>
							<?php }} ?>
							</select>
						<?php }?>
						</div>
					</div>
				</div>
				<div class="box box-warning"> 
					<div class="box-header">
						<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['autoban'];?>
</h3>
						<div class="box-tools pull-right">
							<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
						</div>
					</div>
					<div class="box-body">
						<div class="form-group">
							<label for="new_virtualserver_complain_autoban_count"><?php echo $_smarty_tpl->getVariable('lang')->value['autobancount'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_complain'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_complain'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<input type="number" min="1" step="1" class="form-control" id="new_virtualserver_complain_autoban_count" name="newsettings[virtualserver_complain_autoban_count]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_complain_autoban_count'];?>
" />
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_complain_autoban_time"><?php echo $_smarty_tpl->getVariable('lang')->value['autobantime'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_complain'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_complain'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<div class="input-group">
								<input type="number" min="1" step="1" class="form-control" id="new_virtualserver_complain_autoban_time" name="newsettings[virtualserver_complain_autoban_time]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_complain_autoban_time'];?>
" />
								<div class="input-group-addon">
									<?php echo $_smarty_tpl->getVariable('lang')->value['seconds'];?>

								</div>
							</div>
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_complain_remove_time"><?php echo $_smarty_tpl->getVariable('lang')->value['removetime'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_complain'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_complain'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<div class="input-group">
								<input type="number" min="1" step="1" class="form-control" id="new_virtualserver_complain_remove_time" name="newsettings[virtualserver_complain_remove_time]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_complain_remove_time'];?>
" />
								<div class="input-group-addon">
									<?php echo $_smarty_tpl->getVariable('lang')->value['seconds'];?>

								</div>
							</div>
						<?php }?>
						</div>
					</div>
				</div>
				<div class="box box-danger"> 
					<div class="box-header">
						<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['antiflood'];?>
</h3>
						<div class="box-tools pull-right">
							<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
						</div>
					</div>
					<div class="box-body">
						<div class="form-group">
							<label for="new_virtualserver_antiflood_points_tick_reduce"><?php echo $_smarty_tpl->getVariable('lang')->value['pointstickreduce'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_antiflood'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_antiflood'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<input type="number" min="1" step="1" class="form-control" id="new_virtualserver_antiflood_points_tick_reduce" name="newsettings[virtualserver_antiflood_points_tick_reduce]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_antiflood_points_tick_reduce'];?>
" />
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_antiflood_points_needed_command_block"><?php echo $_smarty_tpl->getVariable('lang')->value['pointsneededblockcmd'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_antiflood'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_antiflood'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<input type="number" min="1" step="1" class="form-control" id="new_virtualserver_antiflood_points_needed_command_block" name="newsettings[virtualserver_antiflood_points_needed_command_block]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_antiflood_points_needed_command_block'];?>
" />
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_antiflood_points_needed_ip_block"><?php echo $_smarty_tpl->getVariable('lang')->value['pointsneededblockip'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_antiflood'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_antiflood'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<input type="number" min="1" step="1" class="form-control" id="new_virtualserver_antiflood_points_needed_ip_block" name="newsettings[virtualserver_antiflood_points_needed_ip_block]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_antiflood_points_needed_ip_block'];?>
" />
						<?php }?>
						</div>
					</div>
				</div>
				<div class="box box-success"> 
					<div class="box-header">
						<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['transfers'];?>
</h3>
						<div class="box-tools pull-right">
							<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
						</div>
					</div>
					<div class="box-body">
						<div class="form-group">
							<label for="new_virtualserver_max_upload_total_bandwidth"><?php echo $_smarty_tpl->getVariable('lang')->value['upbandlimit'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_ft_settings'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_ft_settings'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<div class="input-group">
								<input type="number" min="-1" step="1" class="form-control" id="new_virtualserver_max_upload_total_bandwidth" name="newsettings[virtualserver_max_upload_total_bandwidth]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_max_upload_total_bandwidth'];?>
" />
								<div class="input-group-addon">
									Byte/s
								</div>
							</div>
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_upload_quota"><?php echo $_smarty_tpl->getVariable('lang')->value['uploadquota'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_ft_quotas'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_ft_quotas'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<div class="input-group">
								<input type="number" min="1" step="1" class="form-control" id="new_virtualserver_upload_quota" name="newsettings[virtualserver_upload_quota]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_upload_quota'];?>
" />
								<div class="input-group-addon">
									MiB
								</div>
							</div>
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_max_download_total_bandwidth"><?php echo $_smarty_tpl->getVariable('lang')->value['downbandlimit'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_ft_settings'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_ft_settings'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<div class="input-group">
								<input type="number" min="-1" step="1" class="form-control" id="new_virtualserver_max_download_total_bandwidth" name="newsettings[virtualserver_max_download_total_bandwidth]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_max_download_total_bandwidth'];?>
" />
								<div class="input-group-addon">
									Byte/s
								</div>
							</div>
						<?php }?>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_download_quota"><?php echo $_smarty_tpl->getVariable('lang')->value['downloadquota'];?>
:</label>
						<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_ft_quotas'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_ft_quotas'])){?>
							&nbsp; - 
						<?php }else{ ?>
							<div class="input-group">
								<input type="number" min="1" step="1" class="form-control" id="new_virtualserver_download_quota" name="newsettings[virtualserver_download_quota]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_download_quota'];?>
" />
								<div class="input-group-addon">
									MiB
								</div>
							</div>
						<?php }?>
						</div>
					</div>
				</div>
				<div class="box box-default">
					<div class="box-header">
						<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['logs'];?>
</h3>
						<div class="box-tools pull-right">
							<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
						</div>
					</div>
					<div class="box-body">
						<div class="form-group">
							<label for="new_virtualserver_log_client"><?php echo $_smarty_tpl->getVariable('lang')->value['logclient'];?>
:</label>
							<input type="checkbox" id="new_virtualserver_log_client" name="newsettings[virtualserver_log_client]" value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_client']==='1'){?>checked<?php }?> data-toggle="toggle" data-width="100%" data-onstyle="primary" data-offstyle="warning" data-size="small" data-on="<?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
" data-off="<?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
"/>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_log_query"><?php echo $_smarty_tpl->getVariable('lang')->value['logquery'];?>
:</label>
							<input type="checkbox" id="new_virtualserver_log_query" name="newsettings[virtualserver_log_query]" value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_query']==='1'){?>checked<?php }?> data-toggle="toggle" data-width="100%" data-onstyle="primary" data-offstyle="warning" data-size="small" data-on="<?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
" data-off="<?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
"/>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_log_channel"><?php echo $_smarty_tpl->getVariable('lang')->value['logchannel'];?>
:</label>
							<input type="checkbox" id="new_virtualserver_log_channel" name="newsettings[virtualserver_log_channel]" value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_channel']==='1'){?>checked<?php }?> data-toggle="toggle" data-width="100%" data-onstyle="primary" data-offstyle="warning" data-size="small" data-on="<?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
" data-off="<?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
"/>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_log_permissions"><?php echo $_smarty_tpl->getVariable('lang')->value['logpermissions'];?>
:</label>
							<input type="checkbox" id="new_virtualserver_log_permissions" name="newsettings[virtualserver_log_permissions]" value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_permissions']==='1'){?>checked<?php }?> data-toggle="toggle" data-width="100%" data-onstyle="primary" data-offstyle="warning" data-size="small" data-on="<?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
" data-off="<?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
"/>
						</div>
						<div class="form-group">
							<label for="new_virtualserver_log_server"><?php echo $_smarty_tpl->getVariable('lang')->value['logserver'];?>
:</label>
							<input type="checkbox" id="new_virtualserver_log_server" name="newsettings[virtualserver_log_server]" value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_server']==='1'){?>checked<?php }?> data-toggle="toggle" data-width="100%" data-onstyle="primary" data-offstyle="warning" data-size="small" data-on="<?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
" data-off="<?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
"/>
						</div>							
						<div class="form-group">
							<label for="new_virtualserver_log_filetransfer"><?php echo $_smarty_tpl->getVariable('lang')->value['logfiletransfer'];?>
:</label>
							<input type="checkbox" id="new_virtualserver_log_filetransfer" name="newsettings[virtualserver_log_filetransfer]" value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_filetransfer']==='1'){?>checked<?php }?> data-toggle="toggle" data-width="100%" data-onstyle="primary" data-offstyle="warning" data-size="small" data-on="<?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
" data-off="<?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
"/>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12">
				<input class="btn btn-block btn-flat btn-success" type="submit" name="editserver" value="Edit" />
			</div>
		</form>
	</div>
</section>
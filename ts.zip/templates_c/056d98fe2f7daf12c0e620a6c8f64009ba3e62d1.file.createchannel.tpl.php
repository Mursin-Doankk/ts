<?php /* Smarty version Smarty3rc4, created on 2020-11-06 14:42:00
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/createchannel.tpl" */ ?>
<?php /*%%SmartyHeaderCode:21251546025fa560b83a82e5-94460095%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '056d98fe2f7daf12c0e620a6c8f64009ba3e62d1' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/createchannel.tpl',
      1 => 1513638412,
    ),
  ),
  'nocache_hash' => '21251546025fa560b83a82e5-94460095',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_permanent'])&&isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_semi_permanent'])&&isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_temporary'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_permanent'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_semi_permanent'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_temporary'])){?>
<section class="content container-fluid">
	<div class="row">
		<div class="col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4">
			<div class="box box-danger">
				<div class="box-header"><h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
</h3></div>
				<div class="box-body">
					<p class="lead"><?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>
</p>
				</div>
			</div>
		</div>
	</div>
</section>
<?php }else{ ?>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
	<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
	<?php }?>
	<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
		<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
	<?php }?>
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['createachannel'];?>
</h3>
			</div>
			<div class="box-body">			
				<form method="post" action="index.php?site=createchannel&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
					<table class="table table-striped" cellspacing="0">
							<tr>
								<td width="50%"><label for="new_cpid"><?php echo $_smarty_tpl->getVariable('lang')->value['pid'];?>
:</label></td>
								<td width="50%">
								<select class="form-control" id="new_cpid" name="settings[cpid]">
									<option value="0"><?php echo $_smarty_tpl->getVariable('lang')->value['mainchannel'];?>
</option>
									<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channellist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
									<option value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['channel_name'];?>
</option>
									<?php }} ?>
								</select>
								</td>
							</tr>
							<tr>
								<td><label for="new_channel_name"><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
:</label></td>
								<td><input type="text" class="form-control" id="new_channel_name" name="settings[channel_name]" /></td>
							</tr>
							<tr>
								<td><label for="new_channel_topic"><?php echo $_smarty_tpl->getVariable('lang')->value['topic'];?>
:</label></td>
								<td>
								<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_topic'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_topic'])){?>
									-
								<?php }else{ ?>
									<input type="text" class="form-control" id="new_channel_topic" name="settings[channel_topic]" />
								<?php }?>
								</td>
							</tr>
							<tr>
								<td><label for="new_channel_description"><?php echo $_smarty_tpl->getVariable('lang')->value['description'];?>
:</label></td>
								<td>
								<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_description'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_description'])){?>
									-
								<?php }else{ ?>
									<input type="text" class="form-control" id="new_channel_description" name="settings[channel_description]" />
								<?php }?>
								</td>
							</tr>
							<tr>
								<td><label for="new_channel_codec"><?php echo $_smarty_tpl->getVariable('lang')->value['codec'];?>
:</label></td>
								<td>
									<select class="form-control" id="new_channel_codec" name="settings[channel_codec]">
									<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_speex8'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_speex8']==1){?>
										<option value="0"><?php echo $_smarty_tpl->getVariable('lang')->value['codec0'];?>
</option>
									<?php }?>
									<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_speex16'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_speex16']==1){?>
										<option value="1"><?php echo $_smarty_tpl->getVariable('lang')->value['codec1'];?>
</option>
									<?php }?>
									<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_speex32'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_speex32']==1){?>
									<option value="2"><?php echo $_smarty_tpl->getVariable('lang')->value['codec2'];?>
</option>
									<?php }?>
									<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_celtmono48'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_celtmono48']==1){?>
										<option value="3"><?php echo $_smarty_tpl->getVariable('lang')->value['codec3'];?>
</option>
									<?php }?>
									<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_opusvoice'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_opusvoice']==1){?>
										<option value="3"><?php echo $_smarty_tpl->getVariable('lang')->value['codec4'];?>
</option>
									<?php }?>
									<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_opusmusic'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_opusmusic']==1){?>
										<option value="3"><?php echo $_smarty_tpl->getVariable('lang')->value['codec5'];?>
</option>
									<?php }?>
									</select>
								</td>
							</tr>
							<tr>
								<td><label for="new_channel_codec_quality"><?php echo $_smarty_tpl->getVariable('lang')->value['codecquality'];?>
:</label></td>
								<td>
								<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['i_channel_create_modify_with_codec_maxquality'])&&empty($_smarty_tpl->getVariable('permoverview')->value['i_channel_create_modify_with_codec_maxquality'])){?>
									-
								<?php }else{ ?>
									<select id="new_channel_codec_quality" class="form-control" name="settings[channel_codec_quality]">
										<option value="0">0</option>
										<option value="1">1</option>
										<option value="2">2</option>
										<option value="3">3</option>
										<option value="4">4</option>
										<option value="5">5</option>
										<option value="6">6</option>
										<option value="7">7</option>
										<option value="8">8</option>
										<option value="9">9</option>
										<option value="10">10</option>
									</select>
								<?php }?>
								</td>
							</tr>
							<tr>
								<td><label for="new_channel_maxclients"><?php echo $_smarty_tpl->getVariable('lang')->value['maxclients'];?>
:</label></td>
								<td>
								<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_maxclients'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_maxclients'])){?>
									-
								<?php }else{ ?>
									<input type="text" class="form-control" id="new_channel_maxclients" name="settings[channel_maxclients]" value="-1" />
								<?php }?>
								</td>
							</tr>
							<tr>
								<td><label for="new_channel_maxfamilyclients"><?php echo $_smarty_tpl->getVariable('lang')->value['maxfamilyclients'];?>
:</label></td>
								<td>
								<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_maxfamilyclients'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_maxfamilyclients'])){?>
									-
								<?php }else{ ?>
									<input type="text" class="form-control" id="new_channel_maxfamilyclients" name="settings[channel_maxfamilyclients]" value="-1" />
								<?php }?>
								</td>
							</tr>
							<tr>
								<td><label for="new_chantyp_2"><?php echo $_smarty_tpl->getVariable('lang')->value['type'];?>
:</label></td>
								<td>
								<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_semi_permanent'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_semi_permanent']==1){?>
									<div class="radio">
										<label>
											<input type="radio" name="chantyp" value="1" checked />
											<?php echo $_smarty_tpl->getVariable('lang')->value['semipermanent'];?>

										</label>
									</div>
								<?php }?>
								<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_permanent'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_permanent']==1){?>
									<div class="radio">
										<label>
											<input type="radio" id="new_chantyp_2" name="chantyp" value="2" />
											<?php echo $_smarty_tpl->getVariable('lang')->value['permanent'];?>

										</label>
									</div>
								<?php }?>
								<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_default'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_default']==1){?>
									<div class="radio">
										<label>
											<input type="radio" name="chantyp" value="3" />
											<?php echo $_smarty_tpl->getVariable('lang')->value['default'];?>

										</label>
									</div>
								<?php }?>
								</td>
							</tr>
							<tr>
								<td><label for="new_channel_flag_maxfamilyclients_inherited"><?php echo $_smarty_tpl->getVariable('lang')->value['maxfamilyclientsinherited'];?>
:</label></td>
								<td>
								<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_maxclients'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_maxclients'])){?>
									-
								<?php }else{ ?>
									<select id="new_channel_flag_maxfamilyclients_inherited" class="form-control" name="settings[channel_flag_maxfamilyclients_inherited]">
									<option value="0">0</option>
									<option value="1">1</option>
									</select>
								<?php }?>
								</td>
							</tr>
							<tr>
								<td><label for="new_channel_needed_talk_power"><?php echo $_smarty_tpl->getVariable('lang')->value['neededtalkpower'];?>
:</label></td>
								<td>
								<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_needed_talk_power'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_needed_talk_power'])){?>
									-
								<?php }else{ ?>
									<input type="text" class="form-control" id="new_channel_needed_talk_power" name="settings[channel_needed_talk_power]" value="0" />
								<?php }?>
								</td>
							</tr>
							<tr>
								<td><label for="new_channel_name_phonetic"><?php echo $_smarty_tpl->getVariable('lang')->value['phoneticname'];?>
:</label></td>
								<td><input type="text" class="form-control" id="new_channel_name_phonetic" name="settings[channel_name_phonetic]" /></td>
							</tr>
						</table>
					<input type="submit" name="createchannel" class="btn btn-flat btn-primary btn-block" value="<?php echo $_smarty_tpl->getVariable('lang')->value['create'];?>
" />
				</form>
			</div>
		</div>

	</div>
</section>
<?php }?>
<?php /* Smarty version Smarty3rc4, created on 2020-11-06 16:50:04
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/clients.tpl" */ ?>
<?php /*%%SmartyHeaderCode:563124865fa57ebcb4aef2-77054786%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dc964d28edc99eecd06e244008c6a5f50844f22b' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/clients.tpl',
      1 => 1513638412,
    ),
  ),
  'nocache_hash' => '563124865fa57ebcb4aef2-77054786',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include '/home/victoryf/public_html/ts3panel/libs/Smarty/libs/plugins/modifier.date_format.php';
?><?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_client_list'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_client_list'])||isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_client_dblist'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_client_dblist'])){?>
<section class="content container-fluid">
	<div class="row">
		<div class="col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4">
			<div class="box box-danger">
				<div class="box-header"><h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
</h3></div>
				<div class="box-body">
					<p class="lead"><?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>
</p>
				</div>
			</div>
		</div>
	</div>
</section>
<?php }else{ ?>
<script>
	$(function () {
		var table = $("#clients").DataTable({
            "language": {
                "url": dataTableLang
            },
            "autoWidth": false,
			"order": [[ 0, "desc" ]],
			"processing": true,
			"columnDefs": [
				{ targets: 0, responsivePriority: 1},
				{ targets: 6, responsivePriority: 2},
				{ targets: 'no-sort', orderable: false },
				{ targets: 'no-search', searchable: false }
			],
			initComplete: function() {
				var api = this.api();

				new $.fn.dataTable.Buttons(api, {
					"buttons": [
						{
							text: "<?php echo $_smarty_tpl->getVariable('lang')->value['showmoreentrys'];?>
 <span id='more_entry_act_page'>1</span>/<span id='more_entry_max_pages'><?php if (sprintf('%d',$_smarty_tpl->getVariable('pages')->value)==0){?>1<?php }else{ ?><?php echo $_smarty_tpl->getVariable('pages')->value;?>
<?php }?></span>",
							className: "btn btn-primary btn-flat <?php if (sprintf('%d',$_smarty_tpl->getVariable('pages')->value)==0){?>disabled<?php }?>",
							action: function ( e, dt, node, config ) {
								add_entries();
							}
						}
					]
				});

				$('#clients_length').parent('.col-sm-6').removeClass('col-sm-6').addClass('col-sm-6 col-md-4');
				$('#clients_filter').parent('.col-sm-6').removeClass('col-sm-6').addClass('col-sm-6 col-md-4 col-md-push-4').after('<div class="col-sm-12 col-md-4 col-md-pull-4 text-center"><div id="clients_buttons"></div></div>');		
				$('#clients_processing').css('top', '7%');
				api.buttons().container().prependTo( '#clients_buttons' );
				$('.pagination').addClass('pagination-flat');
			}
		});


		var next_page = 0;

		function add_entries(){
			var max_pages = parseInt("<?php echo $_smarty_tpl->getVariable('pages')->value;?>
");
				max_pages = max_pages-1;
			var url = "index.php?site=clients&sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&getstart="+((next_page+1)*100);

			table.processing(true);
			$('#more_entry_act_page').parents('a').addClass('disabled');

			if (max_pages != next_page) {
				$.get(url, function(data) {
					data = $.parseHTML(data);
					$.each(data, function(key, itm) {
						if (itm.className == 'wrapper') {
							var base = itm.children[2].children[0].children[0].children[1];
							var elems = base.children[1].children[1].children[1].children;
							var lastID = elems.length - 1;
							$.each(elems, function(uKey, uItm){
								table.row.add( [
									uItm.children[0].innerText,
									uItm.children[1].innerText,
									uItm.children[2].innerText,
									uItm.children[3].innerText,
									uItm.children[4].innerText,
									uItm.children[5].innerHTML,
									uItm.children[6].innerHTML
								] ).draw( false );
								if (uKey == lastID) {
									next_page += 1;

									if (next_page != max_pages){
										$('#more_entry_act_page').parents('a').removeClass('disabled');
									}

									$('#more_entry_act_page').text(next_page+1);
									table.processing( false );
								}
							})
						}
					});
				});
			}
		}
	});
</script>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
		<div class="box box-info">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['searchfor'];?>
<?php echo $_smarty_tpl->getVariable('lang')->value['client'];?>
</h3>
			</div>
			<div class="box-body">			
				<form method="post" action="index.php?site=clients&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
					<div class="row">
						<div class="col-lg-3">
							<select class="form-control" name="searchby">
								<option value="uniqueid"><?php echo $_smarty_tpl->getVariable('lang')->value['uniqueid'];?>
</option>
								<option value="cldbid"><?php echo $_smarty_tpl->getVariable('lang')->value['cldbid'];?>
</option>
								<option value="name"><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
</option>
							</select>
						</div>
						<div class="col-lg-6">
							<input type="text" class="form-control" name="search" required />
						</div>
						<div class="col-lg-3">
							<input type="submit" class="btn btn-flat btn-info btn-block" name="sendsearch" value="<?php echo $_smarty_tpl->getVariable('lang')->value['search'];?>
" />					
						</div>
					</div>
				</form>
			</div>
		</div>
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['clients'];?>
</h3>
			</div>
			<div class="box-body">
				<input type="hidden" name="next_page" id="next_page" value="0">
				<table class="table table-striped dt-responsive" id="clients">
					<thead>				
						<tr>
							<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['dbid'];?>
</th>
							<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['uniqueid'];?>
</th>
							<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['nickname'];?>
</th>
							<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['created'];?>
</th>
							<th class="text-center"><?php echo $_smarty_tpl->getVariable('lang')->value['lastonline'];?>
</th>
							<th class="text-center no-sort"><?php echo $_smarty_tpl->getVariable('lang')->value['status'];?>
</th>
							<th></th>
						</tr>
					</thead>
					<?php while ($_smarty_tpl->getVariable('showclients')->value<=$_smarty_tpl->getVariable('duration')->value&&isset($_smarty_tpl->getVariable('clientdblist')->value[$_smarty_tpl->getVariable('getstart')->value])) { ?>
						<tr>
							<td style="vertical-align: middle;" class="text-center"><?php echo $_smarty_tpl->getVariable('clientdblist')->value[$_smarty_tpl->getVariable('getstart')->value]['cldbid'];?>
</td>
							<td style="vertical-align: middle;" class="text-center"><?php ob_start();?><?php echo $_smarty_tpl->getVariable('getstart')->value;?>
<?php $_tmp1=ob_get_clean();?><?php echo $_smarty_tpl->getVariable('clientdblist')->value[$_tmp1]['client_unique_identifier'];?>
</td>
							<td style="vertical-align: middle;" class="text-center"><?php ob_start();?><?php echo $_smarty_tpl->getVariable('getstart')->value;?>
<?php $_tmp2=ob_get_clean();?><?php echo $_smarty_tpl->getVariable('clientdblist')->value[$_tmp2]['client_nickname'];?>
</td>
							<td style="vertical-align: middle;" class="text-center"><?php ob_start();?><?php echo $_smarty_tpl->getVariable('getstart')->value;?>
<?php $_tmp3=ob_get_clean();?><?php echo smarty_modifier_date_format($_smarty_tpl->getVariable('clientdblist')->value[$_tmp3]['client_created'],"%d.%m.%Y - %H:%M:%S");?>
</td>
							<td style="vertical-align: middle;" class="text-center"><?php ob_start();?><?php echo $_smarty_tpl->getVariable('getstart')->value;?>
<?php $_tmp4=ob_get_clean();?><?php echo smarty_modifier_date_format($_smarty_tpl->getVariable('clientdblist')->value[$_tmp4]['client_lastconnected'],"%d.%m.%Y - %H:%M:%S");?>
</td>
							<td style="vertical-align: middle;" class="text-center">
							<?php ob_start();?><?php echo $_smarty_tpl->getVariable('getstart')->value;?>
<?php $_tmp5=ob_get_clean();?><?php if (isset($_smarty_tpl->getVariable('clientdblist')->value[$_tmp5]['clid'])){?>
								<span class="text-green"><?php echo $_smarty_tpl->getVariable('lang')->value['online'];?>
</span>
							<?php }else{ ?>
								<span class="text-red"><?php echo $_smarty_tpl->getVariable('lang')->value['offline'];?>
</span>
							<?php }?>
							</td>
							<td style="vertical-align: middle;" class="text-right no-padding">
								<a class="btn btn-sm btn-flat btn-info no-margin" href="index.php?site=cleditperm&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;cldbid=<?php ob_start();?><?php echo $_smarty_tpl->getVariable('getstart')->value;?>
<?php $_tmp6=ob_get_clean();?><?php echo $_smarty_tpl->getVariable('clientdblist')->value[$_tmp6]['cldbid'];?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['editperms'];?>
</a>
							<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_client_delete_dbproperties'])||$_smarty_tpl->getVariable('permoverview')->value['b_client_delete_dbproperties']==1){?>
								<form method="post" style="display: inline;" action="index.php?site=clients&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
									<input type="hidden" name="cldbid" value="<?php ob_start();?><?php echo $_smarty_tpl->getVariable('getstart')->value;?>
<?php $_tmp7=ob_get_clean();?><?php echo $_smarty_tpl->getVariable('clientdblist')->value[$_tmp7]['cldbid'];?>
" />
									<input type="submit" class="btn btn-sm btn-flat btn-danger" name="clientdel" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
" onclick="return confirm('<?php echo $_smarty_tpl->getVariable('lang')->value['deletemsgclient'];?>
')" />
								</form>
							<?php }?>
							</td>
						</tr>
						<?php $_smarty_tpl->tpl_vars['showclients'] = new Smarty_variable(($_smarty_tpl->getVariable('showclients')->value+1), null, null);?>
						<?php $_smarty_tpl->tpl_vars['getstart'] = new Smarty_variable(($_smarty_tpl->getVariable('getstart')->value+1), null, null);?>
					<?php }?>
				</table>
			</div>
		</div>
	<?php }?>
	</div>
</section>
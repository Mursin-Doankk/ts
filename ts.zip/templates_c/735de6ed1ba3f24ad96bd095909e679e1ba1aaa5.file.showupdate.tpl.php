<?php /* Smarty version Smarty3rc4, created on 2018-02-05 02:16:07
         compiled from "C:\localhost\www\Ts3WebPanel\gelistir2\templates/47/showupdate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:252585a77be6747c1f5-30629593%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '735de6ed1ba3f24ad96bd095909e679e1ba1aaa5' => 
    array (
      0 => 'C:\\localhost\\www\\Ts3WebPanel\\gelistir2\\templates/47/showupdate.tpl',
      1 => 1501881922,
    ),
  ),
  'nocache_hash' => '252585a77be6747c1f5-30629593',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('newwiversion')->value)){?>
<div class="alert alert-warning">
	<?php echo $_smarty_tpl->getVariable('newwiversion')->value;?>

</div>
<?php }?>
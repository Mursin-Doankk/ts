<?php /* Smarty version Smarty3rc4, created on 2018-02-05 10:06:55
         compiled from "C:\localhost\www\Ts3WebPanel\gelistir2\templates/mrstipfan/filelist.tpl" */ ?>
<?php /*%%SmartyHeaderCode:318515a782cbf249e94-01369617%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a60846ac9e790beda4c6f14c16f62350e36e0b81' => 
    array (
      0 => 'C:\\localhost\\www\\Ts3WebPanel\\gelistir2\\templates/mrstipfan/filelist.tpl',
      1 => 1513634812,
    ),
  ),
  'nocache_hash' => '318515a782cbf249e94-01369617',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include 'C:\localhost\www\Ts3WebPanel\gelistir2\libs\Smarty\libs\plugins\modifier.date_format.php';
?><section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
	<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
	<?php }?>
	<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
		<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
	<?php }?>
	<?php if ($_smarty_tpl->getVariable('newserverversion')->value!==true&&!empty($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_version'])){?>
		<div class="alert alert-warning"><?php echo $_smarty_tpl->getVariable('lang')->value['serverupdateav'];?>
<?php echo $_smarty_tpl->getVariable('newserverversion')->value;?>
</div>
	<?php }?>
		<div class="box box-info">
			<div class="box-header">
				<h3 class="box-title"><?php if (!empty($_GET['cid'])){?><?php echo $_smarty_tpl->getVariable('lang')->value['channel'];?>
 (<?php echo $_GET['cid'];?>
 <?php echo $_smarty_tpl->getVariable('chaninfo')->value['channel_name'];?>
)<?php }else{ ?><?php echo $_smarty_tpl->getVariable('lang')->value['filelist'];?>
<?php }?></h3>
			</div>
			<div class="box-body">
				<table class="table">
					<tr>
						<th style="width:25%"><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
</th>
						<th style="width:10%"><?php echo $_smarty_tpl->getVariable('lang')->value['size'];?>
</th>
						<th style="width:25%"><?php echo $_smarty_tpl->getVariable('lang')->value['date'];?>
</th>
						<th style="width:25%"><?php echo $_smarty_tpl->getVariable('lang')->value['channel'];?>
</th>
						<th style="width:10%"><?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
</th>
					</tr>
					<?php if ($_GET['path']!="/"&&!empty($_GET['path'])){?>
					<tr>
						<td colspan="5"><a href="index.php?site=filelist&amp;sid=<?php echo $_GET['sid'];?>
&amp;cid=<?php echo $_smarty_tpl->getVariable('cid')->value;?>
&amp;path=<?php echo $_smarty_tpl->getVariable('newpath')->value;?>
">..</a></td>
					</tr>
					<?php }?>
				<?php if (!empty($_smarty_tpl->getVariable('getallfiles')->value)){?>
					<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('getallfiles')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>	
						<?php if ($_smarty_tpl->tpl_vars['key']->value!=='totalsize'){?>
					<tr>
						<td>
							<?php if ($_smarty_tpl->tpl_vars['value']->value['type']==0){?>
								<img src='gfx/images/folder.png' alt="" /><a href="index.php?site=filelist&amp;sid=<?php echo $_GET['sid'];?>
&amp;path=<?php if ($_GET['path']!="/"){?><?php echo $_GET['path'];?>
<?php }?>/<?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
&amp;cid=<?php if (isset($_smarty_tpl->tpl_vars['value']->value['cid'])){?><?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
<?php }else{ ?><?php echo $_GET['cid'];?>
<?php }?>"><?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</a>
							<?php }else{ ?>
								<img src='gfx/images/file.png' alt="" /> <a href="site/filetransfer.php?sid=<?php echo $_GET['sid'];?>
&amp;cid=<?php if (isset($_smarty_tpl->tpl_vars['value']->value['cid'])){?><?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
<?php }else{ ?><?php echo $_GET['cid'];?>
<?php }?>&amp;path=<?php if ($_GET['path']!="/"){?><?php echo $_GET['path'];?>
<?php }?>&amp;name=<?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
&amp;getfile=1" target="_blank"><?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</a>
							<?php }?>
						</td>
						<td><?php echo $_smarty_tpl->tpl_vars['value']->value['size'];?>
 Mb</td>
						<td><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['value']->value['datetime'],"%d.%m.%Y - %H:%M:%S");?>
</td>
						<td><?php echo $_smarty_tpl->tpl_vars['value']->value['cname'];?>
</td>
						<td><a href="index.php?site=filelist&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;cid=<?php if (isset($_smarty_tpl->tpl_vars['value']->value['cid'])){?><?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
<?php }else{ ?><?php echo $_GET['cid'];?>
<?php }?>&amp;path=<?php if (empty($_GET['path'])){?>/<?php }else{ ?><?php echo $_GET['path'];?>
<?php }?>&amp;name=<?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
&amp;deletefile=1"><?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
</a></td>
					</tr>
					<?php }elseif($_smarty_tpl->tpl_vars['key']->value==='totalsize'){?>
					<tr>
						<td><?php echo $_smarty_tpl->getVariable('lang')->value['totalsize'];?>
</td>
						<td colspan="4"><?php echo $_smarty_tpl->tpl_vars['value']->value;?>
 Mb</td>
					</tr>
						<?php }?>
					<?php }} ?>
				<?php }else{ ?>
					<tr>
						<td colspan="5">
							Keine Dateien gefunden!
						</td>
					</tr>
				<?php }?>
				</table>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-10 col-sm-offset-1 col-md-5 col-md-offset-1 col-lg-5 col-lg-offset-1">
			<div class="box box-primary">
				<div class="box-header">
					<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['upload'];?>
</h3>
				</div>
				<div class="box-body">
					<form enctype="multipart/form-data" method="post" action="index.php?site=filelist&amp;sid=<?php echo $_GET['sid'];?>
&amp;cid=<?php echo $_GET['cid'];?>
&amp;cpw=<?php echo $_GET['cpw'];?>
&amp;path=<?php echo $_GET['path'];?>
">
						<div class="form-group">
						<?php if (empty($_GET['cid'])){?>
							<label for="newfile_cid"><?php echo $_smarty_tpl->getVariable('lang')->value['channel'];?>
</label>
							<select id="newfile_cid" class="form-control" name="cid">
							<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channellist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
								<option value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['channel_name'];?>
</option>
							<?php }} ?>
							</select>
						</div>
						<?php }?>
						<div class="form-group fake-file">
							<label for="newfile_file"><?php echo $_smarty_tpl->getVariable('lang')->value['upload'];?>
:</label>
							<input type="hidden" name="max_file_size" value="8388603" />
							<div class="input-group">
							    <span class="input-group-btn">
									<button type="button" class="btn btn-default btn-flat fake-file-button-browse">
										<span class="mdi mdi-file mdi-lg"></span>
									</button>
								</span>
								<input type="file" name="thefile" id="newfile_file" class="fake-file-input-upload" style="display:none">
								<input type="text" class="fake-file-input-name form-control" readonly>
							</div>
						</div>
						<input type="submit" class="btn btn-primary btn-flat btn-block" name="upload" value="<?php echo $_smarty_tpl->getVariable('lang')->value['upload'];?>
" />
					</form>
				</div>
			</div>
		</div>
		<div class="col-sm-10 col-sm-offset-1 col-md-offset-0 col-md-5 col-lg-5">
			<div class="box box-border-teal">
				<div class="box-header">
					<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['createfolder'];?>
</h3>
				</div>
				<div class="box-body">
					<form method="post" action="index.php?site=filelist&amp;sid=<?php echo $_GET['sid'];?>
&amp;cid=<?php echo $_GET['cid'];?>
&amp;cpw=<?php echo $_GET['cpw'];?>
&amp;path=<?php echo $_GET['path'];?>
">
						<?php if (empty($_GET['cid'])){?>
						<div class="form-group">
							<label for="newfolder_cid"><?php echo $_smarty_tpl->getVariable('lang')->value['channel'];?>
</label>
							<select id="newfolder_cid" class="form-control" name="cid">
							<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channellist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
								<option value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['channel_name'];?>
</option>
							<?php }} ?>
							</select>
						</div>
						<?php }?>
						<div class="form-group">
							<label for="newfolder_name"><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
:</label>
							<input id="newfolder_name" class="form-control" type="text" name="fname" />
						</div>
						<input type="submit" class="btn btn-flat btn-block bg-teal" name="createdir" value="<?php echo $_smarty_tpl->getVariable('lang')->value['createfolder'];?>
" />
					</form>
				</div>
			</div>
		</div>
	</div>
</section>


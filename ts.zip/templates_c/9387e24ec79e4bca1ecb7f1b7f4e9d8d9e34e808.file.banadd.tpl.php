<?php /* Smarty version Smarty3rc4, created on 2020-11-06 16:51:06
         compiled from "/home/victoryf/public_html/ts3panel/templates/mrstipfan/banadd.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11421797115fa57efa4cf9f0-44992217%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9387e24ec79e4bca1ecb7f1b7f4e9d8d9e34e808' => 
    array (
      0 => '/home/victoryf/public_html/ts3panel/templates/mrstipfan/banadd.tpl',
      1 => 1513638412,
    ),
  ),
  'nocache_hash' => '11421797115fa57efa4cf9f0-44992217',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_client_ban_create'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_client_ban_create'])){?>
<section class="content container-fluid">
	<div class="row">
		<div class="col-xs-12 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4">
			<div class="box box-danger">
				<div class="box-header"><h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
</h3></div>
				<div class="box-body">
					<p class="lead"><?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>
</p>
				</div>
			</div>
		</div>
	</div>
</section>
<?php }else{ ?>
<section class="content container-fluid">
	<div class="col-xs-12 col-xs-offset-0 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1 no-padding">
		<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
		<div class="alert alert-danger"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</div>
		<?php }?>
		<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
		<div class="alert alert-info"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</div>
		<?php }?>
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title"><?php echo $_smarty_tpl->getVariable('lang')->value['addban'];?>
</h3>
			</div>
			<div class="box-body">
				<form method="post" action="index.php?site=banadd&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
					<table class="table">
						<tr>
							<th><label for="new_banip"><?php echo $_smarty_tpl->getVariable('lang')->value['ip'];?>
</label></th>
							<td><input type="text" id="new_banip" class="form-control" name="banip" /></td>
						</tr>
						<tr>
							<th><label for="new_banname"><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
</label></th>
							<td><input type="text" id="new_banname" class="form-control" name="banname" /></td>
						</tr>
						<tr>
							<th><label for="new_banuid"><?php echo $_smarty_tpl->getVariable('lang')->value['uniqueid'];?>
</label></th>
							<td><input type="text" id="new_banuid" class="form-control" name="banuid" /></td>
						</tr>
						<tr>
							<th><label for="new_reason"><?php echo $_smarty_tpl->getVariable('lang')->value['reason'];?>
</label></th>
							<td><input type="text" id="new_reason" class="form-control" name="reason" /></td>
						</tr>
						<tr>
							<th><label for="new_bantime"><?php echo $_smarty_tpl->getVariable('lang')->value['bantime'];?>
</label></th>
							<td>
								<div class="input-group">
									<input type="text" id="new_bantime" class="form-control" name="bantime" required />
									<span class="input-group-addon"><?php echo $_smarty_tpl->getVariable('lang')->value['seconds'];?>
</span>
								</div>
							</td>
						</tr>
					</table>
					<input class="btn btn-primary btn-block btn-flat" type="submit" name="addban" value="<?php echo $_smarty_tpl->getVariable('lang')->value['ban'];?>
" />
				</form>
			</div>
		</div>
	</div>
</section>
<?php }?>
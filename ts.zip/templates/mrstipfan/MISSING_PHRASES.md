# MISSING PHARES
 ### index.tpl
  - javascript "Aşağıdaki eylemi gerçekleştirmek için, gerçekten istiyor musun?"

 ### iserverbackup.tpl
  - thead "Örnek Sunucu Yedekleme"
  - input "Seç" 2x

 ### serverbackup.tpl
  - input "Seç" 2x

 ### serveredit.tpl
  - input "Düzenle"

 ### sgroupclients.tpl
  - input "kick"

 ### banlist.tpl
  - input "Ban Kaldır"

 ### any backup page
  - table col "Yedek bulunamadı!"
 
 ### any perm page 
  - a "aus/ein-klappen"